from prettytable import PrettyTable
EPSILON = "ε"
first_sets = {}
follow_sets = {}
terminals = []
non_terminals = []
START_SYMBOL = None
parser_table = {}
tmp_ptable = {}

def is_terminal(symbol):    # 檢查符號是否是終結符
    return symbol in terminals or symbol == EPSILON

def get_productions_for_symbol(symbol, grammar):    # 獲取給定符號的生成式
    productions_for_symbol = {}
    for k, production in grammar.items():
        if production.split('->')[0].strip() == symbol:
            productions_for_symbol[k] = production
    return productions_for_symbol

def get_productions_with_symbol(symbol, grammar):   # 獲取所有包含指定符號的生成式
    productions_with_symbol = {}
    for k, production in grammar.items():
        rhs = production.split('->')[1].strip()
        if symbol in rhs:
            productions_with_symbol[k] = production
    return productions_with_symbol

def merge(to, frm, exclude=None):   # 可選擇性地排除
    if exclude is None:
        exclude = []
    for k in frm:
        if k not in exclude:
            to[k] = frm[k]

def build_first_sets(grammar):
    global first_sets
    first_sets = {}
    build_set(grammar, first_of)
    print("First sets:")
    for k, v in first_sets.items():
        if k not in terminals:
            print("  ", k, ":", list(v.keys()))
    print("")

def first_of(symbol, grammar):
    if symbol in first_sets:   # 確認是否已經計算過
        return first_sets[symbol]

    first = first_sets[symbol] = {}

    if is_terminal(symbol):   # 確認symbol是否為一終結符
        first[symbol] = True
        return first_sets[symbol]

    productions_for_symbol = get_productions_for_symbol(symbol, grammar)
    for production in productions_for_symbol.values():
        rhs = production.split('->')[1].strip()     # 遍歷右部
        for i, production_symbol in enumerate(rhs):
            if production_symbol == EPSILON:    # 含空串EPSILON則將EPSILON加入FIRST SET
                first[EPSILON] = True
                break
            first_of_non_terminal = first_of(production_symbol, grammar)
            if EPSILON not in first_of_non_terminal:    # 不包含EPSILON則將其FIRST SET合併
                merge(first, first_of_non_terminal)
                break
            merge(first, first_of_non_terminal, [EPSILON])  # 合併其FIRST SET，但排除EPSILON
    return first

def build_follow_sets(grammar):
    global follow_sets
    follow_sets = {}
    build_set(grammar, follow_of)
    print("Follow sets:")
    for k, v in follow_sets.items():
        print("  ", k, ":", list(v.keys()))
    print("")

def follow_of(symbol, grammar):
    if symbol in follow_sets:   # 確認是否已經計算過
        return follow_sets[symbol]

    follow = follow_sets[symbol] = {}

    if symbol == START_SYMBOL:  # 將結束符號加入FOLLOW SET
        follow['$'] = True

    productions_with_symbol = get_productions_with_symbol(symbol, grammar)
    for production in productions_with_symbol.values():
        rhs = production.split('->')[1].strip()     # 遍歷右部
        symbol_index = rhs.find(symbol)
        follow_index = symbol_index + 1

        while True:
            if follow_index == len(rhs):    # symbol為最後一個符號時
                lhs = production.split('->')[0].strip()
                if lhs != symbol:
                    merge(follow, follow_of(lhs, grammar))   # 將左部的FOLLOW SET併到symbol的FOLLOW SET
                break
            follow_symbol = rhs[follow_index]
            first_of_follow = first_of(follow_symbol, grammar)
            if EPSILON not in first_of_follow:  # FIRST SET不包含EPSILON則將其合併到symbol的FOLLOW SET
                merge(follow, first_of_follow)
                break
            merge(follow, first_of_follow, [EPSILON])   # 合併其FOLLOW SET，但排除EPSILON
            follow_index += 1
    return follow

def build_set(grammar, builder):
    for production in grammar.values():
        builder(production.split('->')[0].strip(), grammar)

def print_grammar(grammar):
    print("Grammar:")
    for production in grammar.values():
        print("  ", production)
    print("")

def build_non_terminals(grammar):
    global non_terminals
    non_terminals = list({production.split('->')[0].strip() for production in grammar.values()})
    print("NonTerminals:", non_terminals)

def build_terminals(grammar):
    global terminals
    terminals = list({symbol for production in grammar.values() for symbol in production.split('->')[1].strip()
                      if symbol not in non_terminals and symbol != EPSILON and symbol != "'"})
    print("Terminals:", terminals)

def build_parser_table(grammar):
    ptable = {}
    tmp_table = {}

    for k, production in grammar.items():   # 遍歷後將每條生成式分割成左部和右部
        rhs = production.split('->')[1].strip()
        lhs = production.split('->')[0].strip()
        if rhs != EPSILON:  # 右部非不是空串EPSILON則獲取右部第一個符號的FIRST SET
            temp_terminals = first_sets[rhs[0]]
            for term in temp_terminals:
                if lhs not in ptable:   # 確認是否已經在表中
                    ptable[lhs] = {}
                    tmp_table[lhs] = {}
                ptable[lhs][term] = production
                tmp_table[lhs][term] = k
        else:   # 右部為空串EPSILON則獲取左部的FOLLOW SET
            temp_terminals = follow_sets[lhs]
            for term in temp_terminals:
                if lhs not in ptable:   # 確認是否已經在表中
                    ptable[lhs] = {}
                    tmp_table[lhs] = {}
                ptable[lhs][term] = production
                tmp_table[lhs][term] = k
    return ptable, tmp_table

def draw_parsing_table(grammar):
    table = PrettyTable()
    table.field_names = [""] + terminals + ["$"]
    for non_terminal in non_terminals:
        row = [non_terminal]
        for terminal in terminals:
            row.append(parser_table.get(non_terminal, {}).get(terminal, ''))
        row.append(parser_table.get(non_terminal, {}).get('$', ''))
        table.add_row(row)
    print(table)

def solve(input_str, grammar):
    log = [] # 記錄分析過程
    reg = 0 # 標記是否錯誤
    consumed_input = "" # 已輸入
    remain_input = input_str + "$" # 剩餘輸入
    stack = ['$']
    action = "nothing!" # 操作描述
    stack.append(START_SYMBOL)
    while stack:
        top = stack[-1]
        if len(stack) == 1 and remain_input == "$": # 為終結符且當前操作非空串，表當前輸入符號匹配
            action = "Accept!"
            action = "Matched!"
            stack.pop()
            consumed_input += remain_input[0]
            remain_input = remain_input[1:]
        elif top == EPSILON: # 空串即彈出
            stack.pop()
        else: # 為非終結符則查找分析表
            num = tmp_ptable[top].get(remain_input[0])
            if not num: # 輸入不匹配
                stack.pop()
                reg = 1
            else: # 將右部符號按逆序推入
                action = grammar[num]
                if top != remain_input[0]:
                    stack.pop()
                    for t in reversed(action.split('->')[1].strip()):
                        stack.append(t)
        log.append({
            "consumed": consumed_input,
            "stack": ",".join(stack),
            "remain": remain_input,
            "action": action
        })
        if action == "Accept!":
            break
    new_table = PrettyTable()
    new_table.field_names = ["CONSUMEDINPUT", "STACK", "REMAIN", "ACTION"]
    for entry in log:
        new_table.add_row([entry["consumed"], entry["stack"], entry["remain"], entry["action"]])
    print(new_table)
    print("Ans:", "Accept!" if not reg else "Reject! (but accept with err handler!)")

def preprocess_grammar(grammar_file):
    grammar = {}
    with open(grammar_file, 'r') as file:
        lines = file.readlines()
        production_number = 1
        for line in lines:
            if production_number == 1:
                global START_SYMBOL
                START_SYMBOL = line[0]
            if 'esp' in line.strip():
                line = line.replace('esp', EPSILON)
            lhs, rhs = line.strip().split('->') # 按 -> 分割成左右
            lhs = lhs.strip()
            rhs_productions = rhs.split('|')    # 右部按照 | 分割成多個生成式
            for prod in rhs_productions:
                grammar[production_number] = f"{lhs} -> {prod.strip()}"    # 將每個生成式存在grammar字典中
                production_number += 1
    build_non_terminals(grammar)
    build_terminals(grammar)
    return grammar

def start_up(grammar_file, text):
    grammar = preprocess_grammar(grammar_file)
    print_grammar(grammar)
    build_first_sets(grammar)
    build_follow_sets(grammar)
    global parser_table, tmp_ptable
    parser_table, tmp_ptable = build_parser_table(grammar)
    draw_parsing_table(grammar)
    solve(text, grammar)

grammar_file = "grammar.txt"
text = "a+a*a"
start_up(grammar_file, text)
