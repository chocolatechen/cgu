s", command=self.pass_turn, state=Tk.DISABLED)
        self.pass_button.pack()
        self.hint_positions = []
        self.total_time = 0
        cwidth = rvs.BOARD_SIZE * self.cell_size
        Tk.Canvas.__init__(self, master, relief=Tk.RAISED, bd=4, bg='gray', width=cwidth, height=cwidth, cursor="cross")
        self.bind("<1>", self.put_stones)
        for i in range(rvs.BOARD_SIZE):
            for j in range(rvs.BOARD_SIZE):
                bcolor = "#D2B48C"
                x0 = i * self.cell_size + self.margin
                y0 = j * self.cell_size + self.margin
                self.create_rectangle(x0, y0, x0 + self.cell_size, y0 + self.cell_size, fill=bcolor, width=1)

        choice = tkinter.messagebox.askquestion("Choose First Move", "Do you want to move first?")
        if choice == "yes":
            self.isPlayerTurn = True
            self.player_color = "#000000"  # 玩家棋子为黑色
            self.computer_color = "#ffffff"  # 电脑棋子为白色
            self.board = rvs.getInitialBoard()
        else:
            self.isPlayerTurn = False
            self.player_color = "#ffffff"  # 玩家棋子为白色
            self.computer_color = "#000000"  # 电脑棋子为黑色
            self.board = rvs.getInitialBoard(is_player_first=False)
            self.AI_move()

        self.refresh()

    def pass_turn(self):
        if not self.isPlayerTurn:
            return

        # 玩家无子可下,切换到电脑回合
        self.isPlayerTurn = False
        self.after(100, self.AI_move)

    def put_stones(self, event):  # 放置棋子
        valid_positions = rvs.possible_positions(self.board, rvs.PLAYER_NUM)

        # 如果玩家有可下位置,禁用 Pass 按钮
        if valid_positions:
            self.pass_button.config(state=Tk.DISABLED)
        else: