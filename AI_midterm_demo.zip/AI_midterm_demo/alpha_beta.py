import time

BOARD_SIZE = 8
PLAYER_NUM = 2
COMPUTER_NUM = 1
MAX_THINK_TIME = 60
direction = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]


# 初始化棋盤數據
def getInitialBoard(is_player_first=True):
    board = [[0 for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
    half = BOARD_SIZE // 2
    if is_player_first:
        board[half - 1][half - 1] = PLAYER_NUM
        board[half][half] = PLAYER_NUM
        board[half - 1][half] = COMPUTER_NUM
        board[half][half - 1] = COMPUTER_NUM
    else:
        board[half - 1][half - 1] = COMPUTER_NUM
        board[half][half] = COMPUTER_NUM
        board[half - 1][half] = PLAYER_NUM
        board[half][half - 1] = PLAYER_NUM
    return board



# 返回棋子數
def countTile(board, tile):
    stones = 0
    for i in range(0, BOARD_SIZE):
        for j in range(0, BOARD_SIZE):
            if board[i][j] == tile:
                stones += 1

    return stones


# 返回一个顏色棋子可能的下棋位置
def possible_positions(board, tile):
    positions = []
    for i in range(BOARD_SIZE):
        for j in range(BOARD_SIZE):
            if board[i][j] == 0:
                if updateBoard(board, tile, i, j, checkonly=True) > 0:
                    positions.append((i, j))
    return positions

def isOnBoard(x, y):
    return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE


# 是否是合法走法，如果合法返回需要翻轉的棋子列表
def updateBoard(board, tile, i, j, checkonly=False):
    # 該位置已經有棋子或者出界了，返回False
    reversed_stone = 0

    # 臨時將tile 放到指定的位置
    board[i][j] = tile
    if tile == 2:
        change = 1
    else:
        change = 2

    # 要被翻轉的棋子
    need_turn = []
    for xdirection, ydirection in direction:
        x, y = i, j
        x += xdirection
        y += ydirection
        if isOnBoard(x, y) and board[x][y] == change:
            x += xdirection
            y += ydirection
            if not isOnBoard(x, y):
                continue
            # 一直走到出界或不是對方棋子的位置
            while board[x][y] == change:
                x += xdirection
                y += ydirection
                if not isOnBoard(x, y):
                    break
            # 出界了，則没有棋子要翻轉
            if not isOnBoard(x, y):
                continue
            # 是自己的棋子，中間的所有棋子都要翻轉
            if board[x][y] == tile:
                while True:
                    x -= xdirection
                    y -= ydirection
                    # 回到了起點則结束
                    if x == i and y == j:
                        break
                    # 需要翻轉的棋子
                    need_turn.append([x, y])
    # 將前面臨時放上的棋子去掉，即還原棋盤
    board[i][j] = 0  # restore the empty space
    # 沒有要被翻轉的棋子，則走法非法。翻轉棋的規則
    for x, y in need_turn:
        if not (checkonly):
            board[i][j] = tile
            board[x][y] = tile  # 翻轉棋子
        reversed_stone += 1
    return reversed_stone

def evaluate(board):
    player_tiles = countTile(board, PLAYER_NUM)
    computer_tiles = countTile(board, COMPUTER_NUM)
    player_moves = len(possible_positions(board, PLAYER_NUM))
    computer_moves = len(possible_positions(board, COMPUTER_NUM))
    
    # 棋子差異
    tile_diff = player_tiles - computer_tiles
    # 行動力差異
    move_diff = player_moves - computer_moves
    
    # 穩定子和邊角位置的權重
    stable_weight = 4
    corner_weight = 8
    edge_weight = 2

    stable_player = stable_stones(board, PLAYER_NUM)
    stable_computer = stable_stones(board, COMPUTER_NUM)
    corners_player = count_corners(board, PLAYER_NUM)
    corners_computer = count_corners(board, COMPUTER_NUM)
    edges_player = count_edges(board, PLAYER_NUM)
    edges_computer = count_edges(board, COMPUTER_NUM)

    stability_diff = stable_player - stable_computer
    corner_diff = corners_player - corners_computer
    edge_diff = edges_player - edges_computer
    
    score = tile_diff + 2 * move_diff + stable_weight * stability_diff + corner_weight * corner_diff + edge_weight * edge_diff
    return score

def stable_stones(board, tile):
    # 計算穩定子的數量，可以簡化為對角和邊界位置的棋子
    stable_count = 0
    stable_positions = [(0, 0), (0, 7), (7, 0), (7, 7)]
    for x, y in stable_positions:
        if board[x][y] == tile:
            stable_count += 1
    return stable_count

def count_corners(board, tile):
    # 計算角落位置的棋子數
    corners = [(0, 0), (0, 7), (7, 0), (7, 7)]
    return sum(1 for x, y in corners if board[x][y] == tile)

def count_edges(board, tile):
    # 計算邊界位置的棋子數
    edge_count = 0
    for i in range(BOARD_SIZE):
        if board[i][0] == tile:
            edge_count += 1
        if board[i][BOARD_SIZE - 1] == tile:
            edge_count += 1
        if board[0][i] == tile:
            edge_count += 1
        if board[BOARD_SIZE - 1][i] == tile:
            edge_count += 1
    return edge_count



def alphabetaNextPosition(board):
    def alphabeta(board, depth, alpha, beta, maximizing_player):
        if depth == 0 or len(possible_positions(board, PLAYER_NUM)) == 0 or len(possible_positions(board, COMPUTER_NUM)) == 0:
            return countTile(board, PLAYER_NUM) - countTile(board, COMPUTER_NUM)

        if maximizing_player:   #if maximizing_player=true
            max_eval = float('-inf')
            for move in possible_positions(board, PLAYER_NUM):
                elapsed_time = time.time() - start_time
                if elapsed_time > MAX_THINK_TIME:
                    print("Time limit exceeded!")
                    break
                
                new_board = [row[:] for row in board]  # Make a copy of the board
                updateBoard(new_board, PLAYER_NUM, move[0], move[1])
                eval = alphabeta(new_board, depth - 1, alpha, beta, False)
                max_eval = max(max_eval, eval)
                alpha = max(alpha, eval)
                if beta <= alpha:
                    break
            return max_eval
        else:
            min_eval = float('inf') #if maximizing_player=false
            for move in possible_positions(board, COMPUTER_NUM):
                elapsed_time = time.time() - start_time
                if elapsed_time > MAX_THINK_TIME:
                    print("Time limit exceeded!")
                    break
                
                new_board = [row[:] for row in board]  # Make a copy of the board
                updateBoard(new_board, COMPUTER_NUM, move[0], move[1])
                eval = alphabeta(new_board, depth - 1, alpha, beta, True)
                min_eval = min(min_eval, eval)
                beta = min(beta, eval)
                if beta <= alpha:
                    break
            return min_eval

    start_time = time.time()
    best_score = float('-inf')
    best_move = None
    for move in possible_positions(board, COMPUTER_NUM):
        new_board = [row[:] for row in board]  # Make a copy of the board
        updateBoard(new_board, COMPUTER_NUM, move[0], move[1])
        score = alphabeta(new_board, 7, float('-inf'), float('inf'), False) #depth & maximizing_player=false
        if score > best_score:
            best_score = score
            best_move = move

        elapsed_time = time.time() - start_time
        if elapsed_time > MAX_THINK_TIME:
            print("Time limit exceeded!")
            return best_move
    return best_move