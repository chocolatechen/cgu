import alpha_beta as rvs
import tkinter as Tk
import time
import tkinter.messagebox

class ReversiBoard(Tk.Canvas):
    cell_size = 46
    margin = 5
    board = rvs.getInitialBoard()
    validBoard = True
    isPlayerTurn = True
    step = []

    def __init__(self, master):
        self.pass_button = Tk.Button(master, text="Pass", command=self.pass_turn, state=Tk.DISABLED)
        self.pass_button.pack()
        self.hint_positions = []
        self.total_time = 0
        cwidth = rvs.BOARD_SIZE * self.cell_size
        Tk.Canvas.__init__(self, master, relief=Tk.RAISED, bd=4, bg='gray', width=cwidth, height=cwidth, cursor="cross")
        self.bind("<1>", self.put_stones)
        for i in range(rvs.BOARD_SIZE):
            for j in range(rvs.BOARD_SIZE):
                bcolor = "#D2B48C"
                x0 = i * self.cell_size + self.margin
                y0 = j * self.cell_size + self.margin
                self.create_rectangle(x0, y0, x0 + self.cell_size, y0 + self.cell_size, fill=bcolor, width=1)

        choice = tkinter.messagebox.askquestion("Choose First Move", "Do you want to move first?")
        if choice == "yes":
            self.isPlayerTurn = True
            self.player_color = "#000000"  # 玩家棋子为黑色
            self.computer_color = "#ffffff"  # 电脑棋子为白色
            self.board = rvs.getInitialBoard()
        else:
            self.isPlayerTurn = False
            self.player_color = "#ffffff"  # 玩家棋子为白色
            self.computer_color = "#000000"  # 电脑棋子为黑色
            self.board = rvs.getInitialBoard(is_player_first=False)
            self.AI_move()

        self.refresh()

    def pass_turn(self):
        if not self.isPlayerTurn:
            return

        # 玩家无子可下,切换到电脑回合
        self.isPlayerTurn = False
        self.after(100, self.AI_move)

    def put_stones(self, event):  # 放置棋子
        valid_positions = rvs.possible_positions(self.board, rvs.PLAYER_NUM)

        # 如果玩家有可下位置,禁用 Pass 按钮
        if valid_positions:
            self.pass_button.config(state=Tk.DISABLED)
        else:
            # 否则启用 Pass 按钮
            self.pass_button.config(state=Tk.NORMAL)

        # 是否游戲结束
        if self.validBoard == False:
            self.validBoard = True
            self.board = rvs.getInitialBoard()
            self.isPlayerTurn = True

            for numid in self.step:
                self.delete(numid)
            self.step = []
            self.refresh()
            return

        # 電腦輪次
        if not self.isPlayerTurn:
            return
        # 玩家輪次
        x = self.canvasx(event.x)
        y = self.canvasy(event.y)
        # 獲得坐標
        i = int(x / self.cell_size)
        j = int(y / self.cell_size)
        if self.board[i][j] != 0 or rvs.updateBoard(self.board, rvs.PLAYER_NUM, i, j, checkonly=True) == 0:
            return

        rvs.updateBoard(self.board, rvs.PLAYER_NUM, i, j)
        self.refresh()
        self.isPlayerTurn = False
        self.after(100, self.AI_move)

    def get_board(self):
        board = []
        for i in range(rvs.BOARD_SIZE):
            row = []
            for j in range(rvs.BOARD_SIZE):
                row.append(self.board[i][j])
            board.append(row)
        return board

    def AI_move(self):
        while True:
            player_possibility = len(rvs.possible_positions(self.board, rvs.PLAYER_NUM))
            if player_possibility == 0:
                self.isPlayerTurn = False
                self.pass_button.config(state=Tk.NORMAL)
            else:
                self.pass_button.config(state=Tk.DISABLED)
            mcts_possibility = len(rvs.possible_positions(self.board, rvs.COMPUTER_NUM))
            if mcts_possibility == 0:
                break

            #計算時間
            start = time.time()
            # stone_pos = rvs.mctsNextPosition(self.board)    #使用 MCTS 算法找到下一步的最佳位置
            stone_pos = rvs.alphabetaNextPosition(self.get_board())    #使用 alphabeta puring 算法找到下一步的最佳位置
            end = time.time()

            one_time = end - start
            self.total_time += one_time
            print("Computer position:", stone_pos)
            print("Step time:", format(one_time, '.4f'), "s")
            print("Total time:", format(self.total_time, '.4f'), "s")
            rvs.updateBoard(self.board, rvs.COMPUTER_NUM, stone_pos[0], stone_pos[1])   #在棋盤上更新 AI 的棋子位置
            self.refresh()  #在棋盤上更新 AI 的棋子位置

            player_possibility = len(rvs.possible_positions(self.board, rvs.PLAYER_NUM))
            mcts_possibility = len(rvs.possible_positions(self.board, rvs.COMPUTER_NUM))

            if mcts_possibility == 0 or player_possibility > 0:
                break   #如果 AI 無法找到可行位置或者玩家有可行位置，則跳出循環

        if player_possibility == 0 and mcts_possibility == 0:   #如果雙方都無法找到可行位置，則顯示遊戲結果
            self.showResult()
            self.validBoard = False

        self.isPlayerTurn = True

    def showResult(self):
        player_stone = rvs.countTile(self.board, rvs.PLAYER_NUM)
        mcts_stone = rvs.countTile(self.board, rvs.COMPUTER_NUM)

        if player_stone < mcts_stone:
            tkinter.messagebox.showinfo('Game Over', "You won")
        elif player_stone == mcts_stone:
            tkinter.messagebox.showinfo('Game Over', "Draw")
        else:
            tkinter.messagebox.showinfo('Game Over', "You lose")

    def refresh(self):

        for item in self.hint_positions:
            self.delete(item)
        self.hint_positions = []

        # 獲取當前玩家可以下棋的位置
        valid_positions = rvs.possible_positions(self.board, rvs.PLAYER_NUM)

        for i in range(rvs.BOARD_SIZE):
            for j in range(rvs.BOARD_SIZE):
                x0 = i * self.cell_size + self.margin
                y0 = j * self.cell_size + self.margin

                if self.board[i][j] == 0:
                    if (i, j) in valid_positions:
                    # 在這個位置畫一個小圓圈作為提示
                        hint = self.create_oval(x0 + 10, y0 + 10, x0 + self.cell_size - 10, y0 + self.cell_size - 10, outline="red", width=2)
                        self.hint_positions.append(hint)
                    continue
                if self.board[i][j] == rvs.PLAYER_NUM:
                    bcolor = self.player_color
                if self.board[i][j] == rvs.COMPUTER_NUM:
                    bcolor = self.computer_color
                self.create_oval(x0 + 2, y0 + 2, x0 + self.cell_size - 2, y0 + self.cell_size - 2, fill=bcolor, width=0)


class Reversi(Tk.Frame):
    def __init__(self, master=None):
        Tk.Frame.__init__(self, master)
        self.master.title("AI_midterm_demo")
        l_title = Tk.Label(self, text='AI_game_demo', font=('Helvetica', '24', ('bold')), fg='#191970', bg='#D8BFD8',
                           width=12)
        l_title.pack(padx=3, pady=3)
        self.f_board = ReversiBoard(self)
        self.f_board.pack(padx=5, pady=5)


if __name__ == '__main__':
    app = Reversi()
    app.pack()
    app.mainloop()
