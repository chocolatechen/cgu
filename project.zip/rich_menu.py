import requests
from linebot import LineBotApi
import json

header = {"Authorization": '', "Content-Type":""}
line_bot_api = LineBotApi('')

"""
1. 上方 logo 與 名稱點擊後進入 about us
2. 點擊左下方 order history 會讓 user 輸入開始與結束日期, 並輸出這段時間內所有的購買紀錄(包含日期時間與總熱量)
3. 點擊右下方 nutritional info 會讓 user 輸入一個日期, 若此日期存在則輸出環圈圖, 食物圖, 表格, 若不存在則輸出當天沒有購買紀錄 
"""

body = {
    "size": {"width": 2500, "height": 1686},
    "selected": "true",
    "name": "hahaha",
    "chatBarText": "選單",
    "areas":[
        # {
        #   "bounds": {"x": 171, "y": 228, "width": 2158, "height": 568},
        #   "action": {"type": "message", "text": "url"}
        # },
        {
          "bounds": {"x": 171, "y":228, "width": 2158, "height": 568}, # 上方大圖
          "action": {"type": "uri", "uri": "https://e614-61-218-122-234.ngrok-free.app/interface/about"}
        },
        {
          "bounds": {"x": 271, "y": 948, "width": 1004, "height": 591}, # 左下小圖
          "action": {"type": "postback", "data": "action=search_duration"}
        },
        { # nutritional info
          "bounds": {"x": 1180, "y": 948, "width": 1004, "height": 591}, # 右下小圖
          "action": {"type": "postback", "data": "action=search_date"}
        }
    ]
}

# req = requests.request('POST', 'https://api.line.me/v2/bot/richmenu', headers=header,data=json.dumps(body).encode('utf-8'))
# print(f"req.text: {req.text}")

with open("richmenu.png", 'rb') as f:
    line_bot_api.set_rich_menu_image("richmenu-b2cef2aaa01fdeee47d7da890f11d1da", "image/png", f)
req = requests.request("POST", "", headers=header)

# line_bot_api.delete_rich_menu("")
