from flask import Flask, request, abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import *
import os
from flask_mysqldb import MySQL
import requests
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import datetime
# import dropbox
import time
import paramiko

app = Flask(__name__)
mysql = MySQL(app)

app.config['MYSQL_HOST'] = ''
app.config['MYSQL_USER'] = ''
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = ''

# channel access token
line_bot_api = LineBotApi('')
# channel secret
handler = WebhookHandler('')

# imgur token
imgur_token = ''

#dropbox access token
# dropbox_token = ""
# dbx = dropbox.Dropbox(dropbox_token)

user_input_status = {}
add_user_RFID = []
add_user_line_id = []
new_member_RFID = []
waste_RFID = []

@app.route('/newWaste', methods=['POST'])
def new_Waste():
    waste_finish = request.form.get("new_waste")
    print(f"waste finish message: {waste_finish}")
    print_after_record(waste_RFID, waste_finish)
    return "Variable received by Flask"

@app.route('/waste', methods=['POST'])
def after_eating():
    waste_RFID.append(request.form.get("waste"))
    print(f"waste_RFID: {waste_RFID}")
    # print_after_record(waste_RFID)
    return "Variable received by Flask"

@app.route('/deleteData', methods=['POST'])
def deleteData():
    user_add_complete = request.form.get('delete_data')
    print(f"onclick received from Django: {user_add_complete}")
    add_user_info2database(add_user_RFID, add_user_line_id, user_add_complete)
    print(f"new_member_RFID: {new_member_RFID}")
    print(f"add_user_RFID: {add_user_RFID}")
    print(f"add_user_line_id: {add_user_line_id}")
    return "Variable received by Flask"

@app.route('/newRecord', methods=['POST'])
def receive_new_record():
    new_record = request.form.get('new_record')
    print(f"new record info: {new_record}")
    print_new_record(new_record)
    print(f"new_member_RFID: {new_member_RFID}")
    print(f"add_user_RFID: {add_user_RFID}")
    print(f"add_user_line_id: {add_user_line_id}")
    return "Variable received by Flask"

@app.route('/endpoint', methods=['POST'])
def receive_variable():
    add_user_RFID.append(request.form.get('endpoint'))
    print(f"RFID received from Django: {add_user_RFID}")
    add_user_info2database(add_user_RFID, add_user_line_id)

    return "Variable received by Flask"

@app.route("/callback", methods=['POST'])
def callback():
    signature = request.headers['X-Line-Signature']
    body = request.get_data(as_text=True)

    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)
    return 'OK'

@handler.add(FollowEvent)
def handle_follow(event):
    add_user_line_id.append(event.source.user_id)
    # print(f"user_line_id: {add_user_line_id}")
    # print(add_user_RFID)
    add_user_info2database(add_user_RFID, add_user_line_id)
    print(add_user_RFID)

@handler.add(PostbackEvent)
def handle_postback(event):
    postback_data = event.postback.data
    userLine = event.source.user_id
    cursor = mysql.connection.cursor()
    cursor.execute(f"SELECT user_id FROM interface_user WHERE user_line = \"{userLine}\"")
    # user_id_result = cursor.fetchone()
    
    # 單一日期查詢
    if postback_data == 'action=search_date':
        info_button_start_time = time.time()
        date_picker = DatetimePickerTemplateAction(
            label="選擇日期",  # 按鈕的文字
            data="action=select_date",  # 用於接收日期選擇器回傳的數據
            mode="date",  # 選擇器模式，此處為日期模式
        )

        buttons_template = ButtonsTemplate(
            text="請選擇要查詢的日期",
            actions=[date_picker],
        )

        template_message = TemplateSendMessage(
            alt_text="日期選擇器",
            template=buttons_template,
        )

        line_bot_api.reply_message(event.reply_token, template_message)
        info_button_end_time = time.time()
        info_button_time = info_button_end_time - info_button_start_time
        print(f"info button time: {info_button_time}")

    elif postback_data == 'action=select_date':
        info_start_time = time.time()
        selected_date = event.postback.params['date']
        cursor = mysql.connection.cursor()
        cursor.execute(f"SELECT food_img, donut_chart_img, sheet_img FROM interface_record WHERE eat_date = '{selected_date}' AND user_line = \"{userLine}\";")
        a_history_record_result = cursor.fetchall()
        # print(f"a history srecord result: {a_history_record_result}")
        cursor.close()
        info_query_time = time.time()
        if len(a_history_record_result) == 0:
            line_bot_api.reply_message(event.reply_token, TextMessage(text=f"您那天沒有用餐"))
        else:
            message_reply = []
            for i in range(len(a_history_record_result)):
                message_reply.append(
                    ImageSendMessage(
                        original_content_url = a_history_record_result[i][0], # 要輸出的圖
                        preview_image_url = a_history_record_result[i][0]
                    )
                )
                message_reply.append(
                    ImageSendMessage(
                        original_content_url = a_history_record_result[i][1],
                        preview_image_url = a_history_record_result[i][1]
                    )
                )
                message_reply.append(
                    ImageSendMessage(
                        original_content_url = a_history_record_result[i][2],
                        preview_image_url = a_history_record_result[i][2]
                    )
                )
                line_bot_api.push_message(userLine, messages=message_reply)
                message_reply.clear()
        info_end_time = time.time()
        info_time = info_end_time - info_start_time
        print(f"info time: {info_time}")
        info_time = info_query_time - info_start_time
        print(f"info query time: {info_time}")
    elif postback_data == 'action=search_duration':
        order_button_start_time = time.time()
        start_date_picker = DatetimePickerTemplateAction(
            label="起始日期",
            data="action=select_start_date",
            mode="date",
        )

        # 結束日期選擇器
        end_date_picker = DatetimePickerTemplateAction(
            label="結束日期",
            data="action=select_end_date",
            mode="date",
        )

        # 按鈕模板包含起始與結束日期選擇器
        buttons_template = ButtonsTemplate(
            text="請選擇日期區間",
            actions=[start_date_picker, end_date_picker],
        )

        # 建立模板訊息
        template_message = TemplateSendMessage(
            alt_text="日期區間選擇器",
            template=buttons_template,
        )
        line_bot_api.reply_message(event.reply_token, template_message)
        order_button_end_time = time.time()
        order_button_time = order_button_end_time - order_button_start_time
        print(f"order_button_time: {order_button_time}")
    
    elif postback_data.startswith('action=select_start_date'):
        selected_start_date = event.postback.params['date']
        user_input_status[event.source.user_id] = {'start_date': selected_start_date}
        
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=f"你選擇了{selected_start_date}，請接著選擇結束日期\n若要修改起始日期可再次選擇起始日期")
        )

    elif postback_data.startswith('action=select_end_date'):
        if event.source.user_id in user_input_status and 'start_date' in user_input_status[event.source.user_id]:
            order_history_start_time = time.time()
            selected_end_date = event.postback.params['date']
            user_input_status[event.source.user_id]['end_date'] = selected_end_date
            start_date = user_input_status[event.source.user_id]['start_date']
            end_date = user_input_status[event.source.user_id]['end_date']

            # print(event.source.user_id)
            cur = mysql.connection.cursor()
            cur.execute(f"SELECT eat_date, eat_time, total_weight, total_cal, total_pro, total_carbo, total_fat, cost FROM interface_record WHERE eat_date BETWEEN '{start_date}' AND '{end_date}' AND user_line = \'{userLine}\';")
            info_result = cur.fetchall()
            # print(f"info result: {info_result}")
            cur.close()
            order_history_query_time = time.time()
            line_chart_url = plot_graph(info_result)
            print(line_chart_url)
            order_history_chart_time = time.time()
            order_history_time = order_history_chart_time - order_history_query_time
            print(f"order_history_chart_time: {order_history_time}")

            msg = []
            if line_chart_url:
                print(line_chart_url)
                msg.append(
                    ImageSendMessage(
                        original_content_url = line_chart_url,
                        # original_content_url = f"\"{line_chart_url}\"",
                        preview_image_url = line_chart_url
                    ))    
            line_bot_api.reply_message(event.reply_token, messages=msg)

            order_history_end_time = time.time()
            order_history_time = order_history_end_time - order_history_start_time
            print(f"order_history_time: {order_history_time}")
            order_history_time = order_history_query_time - order_history_start_time
            print(f"order_history_query_time: {order_history_time}")
            # 清除使用者輸入狀態
            del user_input_status[event.source.user_id]
        else:
            # 如果使用者還未選擇起始日期，回應提醒使用者先選擇起始日期
            line_bot_api.reply_message(
                event.reply_token,
                TextSendMessage(text="請先選擇起始日期")
            )

def print_after_record(waste_RFID, info_print_complete = "0"):
    if info_print_complete == "1":
        cursor = mysql.connection.cursor()
        cursor.execute(f"SELECT user_id, user_line FROM interface_user WHERE user_RFID = \'{waste_RFID[0]}\'")
        user_info_result = cursor.fetchone()
        if user_info_result is not None:
            cursor.execute(f"SELECT record_id FROM interface_record_after WHERE user_line = \'{user_info_result[1]}\' ORDER BY record_id DESC LIMIT 1;")
            record_id_result = cursor.fetchone()
            cursor = mysql.connection.cursor()
            cursor.execute(f"SELECT donut_chart_img, sheet_img from interface_record_after WHERE record_id = {record_id_result[0]};")
            a_record_result = cursor.fetchone()
            cursor.close()

            try:
                message_reply = [
                ImageSendMessage(
                    original_content_url = a_record_result[0], # 要輸出的圖
                    preview_image_url = a_record_result[0]
                ),
                ImageSendMessage(
                    original_content_url = a_record_result[1],
                    preview_image_url = a_record_result[1]
                )]
                line_bot_api.push_message(f"{user_info_result[1]}", messages=message_reply)
                # new_member_RFID.clear()
            except Exception as e:
                print(f"error: {e}")

        waste_RFID.pop(0)
        print(f"waste RFID: {waste_RFID}")
        print("finish print after record")

def print_new_record(newRecord):
    if newRecord == "1":
        print("sent to line")
        print(f"new_member_RFID: {new_member_RFID}")
        print(f"add_user_RFID: {add_user_RFID}")
        print(f"add_user_line_id: {add_user_line_id}")
        cursor = mysql.connection.cursor()
        # print(f"RFID: {RFID}")
        cursor.execute(f"SELECT user_id, user_line FROM interface_user WHERE user_RFID = \'{new_member_RFID[0]}\'")
        user_info_result = cursor.fetchone()
        # print(user_info_result)
        if user_info_result is not None:
        # print(f"user_id_result[0]: {user_info_result[0]}")
            cursor.execute(f"SELECT record_id FROM interface_record WHERE user_line = \'{user_info_result[1]}\' ORDER BY record_id DESC LIMIT 1;")
            record_id_result = cursor.fetchone()
        # print(f"record_id_result[0]: {record_id_result[0]}")

        # 獲取單筆 record 的 info
            cursor = mysql.connection.cursor()
            cursor.execute(f"SELECT food_img, donut_chart_img, sheet_img from interface_record where record_id = {record_id_result[0]};")
            a_record_result = cursor.fetchone()
            cursor.close()

            try:
                message_reply = [
                ImageSendMessage(
                    original_content_url = a_record_result[0], # 要輸出的圖
                    preview_image_url = a_record_result[0]
                ),
                ImageSendMessage(
                    original_content_url = a_record_result[1],
                    preview_image_url = a_record_result[1]
                ),
                ImageSendMessage(
                    original_content_url = a_record_result[2],
                    preview_image_url = a_record_result[2]
                )]
                line_bot_api.push_message(f"{user_info_result[1]}", messages=message_reply)
                # new_member_RFID.clear()
            except Exception as e:
                print(f"error: {e}")
        new_member_RFID.pop(0)
    else:
        print(f"no new record")

def add_user_info2database(add_user_RFID, user_id, user_add_complete = "0"):
    try:
        if user_add_complete == "1":
            new_member_RFID.append(add_user_RFID.pop(0))
            print(f"new_member_RFID: {new_member_RFID}")
            print(f"add_user_RFID: {add_user_RFID}")
            print(f"add_user_line_id: {add_user_line_id}")
            print("delete data finish")
        elif len(add_user_line_id) != 0 and len(add_user_RFID) != 0:
            cur = mysql.connection.cursor()
            cur.execute(f"INSERT INTO interface_user (user_RFID, user_line) values (\'{add_user_RFID[0]}\', \'{user_id[0]}\');")
            mysql.connection.commit()
            cur.close()
            add_user_line_id.pop(0)
            print(f"add user to database finish")
            variable_to_send = "1"
            if variable_to_send == "1":
                # 傳送變數到django
                django_url = "https://18fc-211-72-73-205.ngrok-free.app/interface/getUserBool"
                response = requests.get(django_url, {'add_database': "1"})
                variable_to_send = "0"
                # new_member_RFID.append(add_user_RFID.pop(0))
                # add_user_line_id.clear()
                # add_user_RFID.pop(0)
                print(response.status_code)
                # add_user_line_id.pop(0)
                if response.status_code == 200:
                    print("message sent successfully to django!")
                else:
                    print("Failed to send message to django")
        else:
            print(f"some is less")
    except Exception as e:
        print(f"error adding user to the database: {e}")

def plot_graph(info_result):
    dates = [item[0] for item in info_result]
    times = [item[1].total_seconds() / 3600 for item in info_result]
    weights = [float(item[2]) for item in info_result]
    calories = [float(item[3]) for item in info_result]
    proteins = [float(item[4]) for item in info_result]
    carbons = [float(item[5]) for item in info_result]
    fats = [float(item[6]) for item in info_result]
    costs = [float(item[2]) for item in info_result]
    
    dates_format = [datetime.datetime.combine(date, datetime.time(hour=int(time), minute=int(60 * (time % 1)))) for date, time in zip(dates, times)]
    
    fig, ax1 = plt.subplots(figsize=(10, 6))
    # 折線圖
    line1, = ax1.plot(dates_format, weights, label="Weight", marker='o', linestyle='-', color='b')
    line2, = ax1.plot(dates_format, calories, label="Carlorie", marker='o', linestyle='-', color='r')
    line3, = ax1.plot(dates_format, proteins, label="Protein", marker='o', linestyle='-', color='g')
    line4, = ax1.plot(dates_format, carbons, label="Carbohydrate", marker='o', linestyle='-', color='y')
    line5, = ax1.plot(dates_format, fats, label="Fat", marker='o', linestyle='-', color='m')
    
    ax1.set_xticks(dates_format)

    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d\n%H:%M'))

    # 設置標題與標籤
    ax2 = ax1.twinx()
    bar1 = ax2.bar(dates_format, costs, alpha=0.5, color="purple", label="Cost")

    ax1.set_title("Nutrient Consumption Over Time", fontsize = 16)
    ax1.set_xlabel("Date & Time", fontsize = 14)
    ax1.set_ylabel("Value", fontsize = 14)
    ax2.set_ylabel("Cost", fontsize = 14)

    lines = [line1, line2, line3, line4, line5, bar1]
    labels = [l.get_label() for l in lines]
    fig.legend(lines, labels, loc='upper right', bbox_to_anchor=(0.88, 0.88), ncol=1, fontsize=12)

    line_chart_path = "nutrient_chart.png"
    plt.savefig(line_chart_path)
    plt.close()

    line_chart_url = upload_image(line_chart_path, imgur_token)
    # line_chart_url = upload_file_to_windows_ec2(line_chart_path)
    return line_chart_url

def upload_image(img_path, imgur_token):
    headers = {
        'Authorization': f'Bearer {imgur_token}',
    }
    # 將照片讀取為二進制數據
    with open(img_path, 'rb') as img_file:
        img_data = img_file.read()
    # 設定上傳的 URL
    upload_url = 'https://api.imgur.com/3/upload'
    # 設定上傳的參數
    upload_params = {
        'image': img_data,
    }
    # 發送 POST 請求進行上傳
    response = requests.post(upload_url, headers=headers, files=upload_params)
    
    # 解析 API 回應
    if response.status_code == 200:
        data = response.json()
        link = data['data']['link']
        print(f'照片上傳成功！連結：{link}')

        try:
            os.remove(img_path)
            print(f"本地端照片已刪除: {img_path}")
        except OSError as e:
            print(f"刪除本地照片失敗: {e}")
        return link
    else:
        print(f'照片上傳失敗。錯誤碼：{response.status_code}')
        return None

def upload_file_to_windows_ec2(local_file_path):
    ec2_ip = ''
    username = ""
    password = ""
    remote_file_path = "C:\\Users\\Administrator\\Downloads\\image_data\\"
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    upload_file_name = f"{remote_file_path}{current_time}.jpg"
    try:
        # 創建SSH client
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        # 連接EC2
        ssh.connect(hostname=ec2_ip, username=username, password=password)
        
        # 使用SFTP上傳圖片
        sftp = ssh.open_sftp()
        sftp.put(local_file_path, upload_file_name)
        sftp.close()

        print(f"文件已成功上傳到 {remote_file_path}")
        return f"{current_time}.jpg"

    except Exception as e:
        print(f"文件上傳失败: {e}")
    
    finally:
        # 关闭SSH连接
        ssh.close()

"""
def upload_to_dropbox(local_file, dropbox_path):
    with open(local_file, "rb") as f:
        # 上傳文件到 Dropbox
        dbx.files_upload(f.read(), dropbox_path, mute=True)

    # 創建檔案URL
    shared_link_metadata = dbx.sharing_create_shared_link_with_settings(dropbox_path)
    
    # 獲取檔案URL
    url = shared_link_metadata.url
    
    # 修改URL，使其可以直接下載文件
    download_url = url.replace("?dl=0", "?dl=1")
    
    return download_url
"""
    
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host='0.0.0.0', port=port, debug=True)