<?php
    session_start();
    require_once("db.php");

    if (isset($_SESSION['member_id']) && $_SESSION['member_id'] == true) {
        $theMemberid = $_SESSION['member_id'];
    }

    if (isset($_POST["saveBt"])){
        $Email = $_POST["Email"];
        $Name = $_POST["Name"];
        $Phone = $_POST["MobilePhone"];
        $NewPassword = $_POST["NewPassword"];
        $ConfirmNewPassword = $_POST["ConfirmNewPassword"];

        $sql = "SELECT * FROM `user_info` WHERE `email` = '$Email'";
        $result = mysqli_query($link, $sql);
        $rowCount = mysqli_num_rows($result);

        if (!empty($Email) && !empty($Name) && !empty($Phone) && empty($NewPassword) && empty($ConfirmNewPassword)) {
            if ($rowCount > 0) {
                $alert = "電子信箱已經註冊過!";
                echo "<script type='text/javascript'>alert('$alert');</script>";
            } else {
                $dataSql = "UPDATE `user_info` SET `email` = '$Email', `user_name` = '$Name', `phone` = '$Phone' WHERE `member_id` = '$theMemberid'";
                mysqli_query($link, $dataSql);
                unset($_SESSION['member_id']);
                echo "<script type='text/javascript'>alert('資料修改成功!'); window.location.href = 'login.php';</script>";
            }
        } else if (!empty($NewPassword) && !empty($ConfirmNewPassword) && empty($Email) && empty($Name) && empty($Phone)) {
            if ($NewPassword === $ConfirmNewPassword){
                $updateSql = "UPDATE `user_info` SET `user_password` = '$NewPassword' WHERE `member_id` = '$theMemberid'";
                $updateResult = mysqli_query($link, $updateSql);
                unset($_SESSION['member_id']);
                echo "<script type='text/javascript'>alert('密碼修改成功!'); window.location.href = 'login.php';</script>";
            } else {
                $alert = "新密碼和確認密碼不相同!";
                echo "<script type='text/javascript'>alert('$alert');</script>";
            }
        } else {
            $alert = "請輸入完整資料!";
            echo "<script type='text/javascript'>alert('$alert');</script>";
        }
    }
    mysqli_close($link);
?>

<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="Style_profile.css">
  <title>肯德基登入系統</title>
</head>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // 初始顯示資料修改區域
        document.getElementById('dataModificationSection').style.display = 'block';
        // 隱藏變更密碼區域
        document.getElementById('changePasswordSection').style.display = 'none';

        // 資料修改按鈕的點擊事件
        document.getElementById('btnDataModification').addEventListener('click', function () {
            // 顯示資料修改區域
            document.getElementById('dataModificationSection').style.display = 'block';
            // 隱藏變更密碼區域
            document.getElementById('changePasswordSection').style.display = 'none';
            // 清除變更密碼區域的輸入框
            document.getElementById('txtNewPassword').value = '';
            document.getElementById('txtConfirmNewPassword').value = '';
        });

        // 變更密碼按鈕的點擊事件
        document.getElementById('btnChangePassword').addEventListener('click', function () {
            // 顯示變更密碼區域
            document.getElementById('changePasswordSection').style.display = 'block';
            // 隱藏資料修改區域
            document.getElementById('dataModificationSection').style.display = 'none';
            // 清除資料修改區域的輸入框
            document.getElementById('txtEmail').value = '';
            document.getElementById('txtName').value = '';
            document.getElementById('MobilePhone').value = '';
        });
    });
    function redirectToMenu(menuType) {
        const menuHtmlFiles = {
          '個人餐': 'personal_meal.php',
          '多人餐': 'family_meal.php',
          '早餐': 'breakfast.php',
          '單點': 'single_item.php',
        };
        const menuHtmlFile = menuHtmlFiles[menuType];
        if (menuHtmlFile) {
          window.location.href = menuHtmlFile;
        }
      }
</script>

<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>

    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
      </div>


      <div class="container">
        <div class="dataTran-form">
                <!-- 按鈕區域 -->
                <div id="buttonSection">
                    <button type="button" class="btn" id="btnDataModification">資料修改</button>
                    <button type="button" class="btn" id="btnChangePassword">變更密碼</button>
                </div>
            <!-- 資料修改區域 -->
            <form action="#" method="post" id="modifydata">
                <div id="dataModificationSection">
                    <!-- 資料修改區域的輸入框 -->
                    <label for="txtEmail">電子信箱:</label>
                    <input type="email" id="txtEmail" name="Email" placeholder="請輸入新的電子信箱">
                    <label for="txtName">姓名:</label>
                    <input type="text" id="txtName" name="Name" placeholder="請修改姓名">
                    <label for="txtPhone">電話號碼:</label>
                    <div class="input-wrapper">
                        <input type="text" id="MobilePhone" name="MobilePhone" maxlength="10" placeholder="請輸入新的手機號碼">
                    </div>
                </div>
        
                <!-- 變更密碼區域 -->
                <div id="changePasswordSection">
                    <!-- 變更密碼區域的輸入框 -->
                    <label for="txtNewPassword">新密碼:</label>
                    <input type="password" id="txtNewPassword" name="NewPassword" placeholder="請輸入新密碼">
                    <label for="txtConfirmNewPassword">確認新密碼:</label>
                    <input type="password" id="txtConfirmNewPassword" name="ConfirmNewPassword" placeholder="請再次輸入新密碼">
                </div>
            
            
                <!-- 確認送出按鈕 -->
                <button type="submit" class="btn block" id="btnSave" name="saveBt"><span>確認送出</span></button>
            </form>
        </div>
    </div>
    
      
      <div class="center-buttons-and-current-page">
        <button type="button" class="action-button" onclick="location.href='history.php'">
            訂單資料
        </button>
        <button type="button" class="action-button" onclick="location.href='profile.php'">  
          <div class="current-page">
          <span id="currentPageLabel">個人資料</span>
      </div></button>
      
      <div class="separator"></div>
      <button type="button" class="action-button" onclick="logout()">
        登出
      </button>
      </div>
      <script>
        function logout() {
          // 使用 AJAX 请求执行登出操作
          var xhr = new XMLHttpRequest();
          xhr.open("POST", "logout.php", true);
          xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

          xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
              // 登出成功后，跳转到首页
              window.location.href = 'index.php';
            }
          };

          xhr.send();
        }
      </script>   
