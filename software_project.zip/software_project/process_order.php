<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedCounty = $_POST["selectedCounty"];
    $selectedDistrict = $_POST["selectedDistrict"];
    $selectedDate = $_POST["selectedDate"];
    list($orderDate, $orderTime) = explode("T", $selectedDate);

    // 將資訊存入 SESSION
    // $_SESSION["selectedCounty"] = $selectedCounty;
    // $_SESSION["selectedDistrict"] = $selectedDistrict;
    $_SESSION["orderDate"] = $orderDate;
    $_SESSION["orderTime"] = $orderTime;

    // 如果需要上傳至 SQL 數據庫，這裡可以添加相應的程式碼

    // 回傳一些訊息給 JavaScript，可選
    // echo "Order information received successfully.";
}
?>
