<?php
session_start();
require_once('db.php');
?>

<?php
    if (isset($_SESSION['member_id']) && $_SESSION['member_id'] == true) {
        $theMemberid = $_SESSION['member_id'];
    }

    ini_set('display_errors', '1');

    $sqlOrder = "SELECT `meal_name` , `num_meal`, `total_price`, `meal_deliver` FROM `customer_order` WHERE `member_id` = '$theMemberid' and `is_pay` = 0";
    $result = mysqli_query($link, $sqlOrder);

    # 輸出餐點內容
    $totalPrice = 0;
    while ($contentOrder = @$result->fetch_assoc()) {
        $totalPrice += $contentOrder["total_price"];
        $mealDeliver = $contentOrder["meal_deliver"];
    }
    if ($mealDeliver == 1) {
        $deliverString = "專業外送";
    } else {
        $deliverString = "預定快取";
    }

    $sqlUser = "SELECT `email` , `phone`, `user_name` FROM `user_info` WHERE `member_id` = '$theMemberid'";
    $resultUser = mysqli_query($link, $sqlUser);
    $contentUser = $resultUser->fetch_assoc();
    $theEmail = $contentUser['email'];
    $thePhone = $contentUser['phone'];
    $theName = $contentUser['user_name'];
    
    # 從資料庫取餐廳
    $sqlRestaurant = "SELECT `restaurant_name` FROM `customer_order` WHERE `member_id` = '$theMemberid' and `is_pay` = 0";
    $restaurantResult = mysqli_query($link, $sqlRestaurant);
    if ($restaurantResult) {
        $row = $restaurantResult->fetch_assoc();

        if ($row) {
            $restaurantName = $row['restaurant_name'];
            // echo $restaurantName;
            $sqlAddress = "SELECT `restaurant_city`, `restaurant_area`, `restaurant_address` FROM `restaurant` WHERE '$restaurantName' = `restaurant_name`";
            $addressResult = mysqli_query($link, $sqlAddress);
            
            if ($addressResult) {
                $row2 = $addressResult->fetch_assoc();
            
                if ($row2) {
                    $realAddress = $row2["restaurant_city"] . $row2["restaurant_area"] . $row2["restaurant_address"];
                }
            }
        }
    }

    # 從資料庫取日期時間
    $sqlTime = "SELECT `order_date`, `order_time` FROM `customer_order` WHERE `customer_name` = 'chocolate' and `is_pay` = 0";
    $resultTime = mysqli_query($link, $sqlTime);
    $contentTime = @$resultTime->fetch_assoc();
    $orderDate = $contentTime["order_date"];
    $orderTIme = $contentTime["order_time"];
?>

<!DOCTYPE html>
<html lang="UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="paybill.css">
    <title>肯德基登入系統</title>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    
    <div class="paybill-container">
        <div class="header-text">
            <p>&nbsp&nbsp餐點內容</p>
        </div>
        <div class="paybill-card">
            <ul>
                <?php
                    $sqlOrder = "SELECT `meal_name` , `num_meal`, `total_price`, `meal_deliver` FROM `customer_order` WHERE `member_id` = '$theMemberid' and `is_pay` = 0";
                    $result = mysqli_query($link, $sqlOrder);
                    
                    while ($contentOrder = $result->fetch_assoc()) {
                        echo '<div class="meals-container">';
                        echo '<li>' . $contentOrder['meal_name'] . '</li>';
                        echo '<div class="price">$' . $contentOrder['total_price'] . '</div>';
                        echo '</div>';
                        echo "<button class='change-meals-button' onclick=\"redirectToMenu('修改')\">修改餐點</button>";
                    }
                ?>
            </ul>           
        </div>
        <div class="header-text">
            <p>&nbsp&nbsp訂餐內容</p>
        </div>
    </div>
    <hr>
        <div class="price-container">
            <div class="additional-text">合計餐點金額</div>
            <div class="price"><?php echo $totalPrice?></div>
        </div>
        <div class="price-container">
            <div class="additional-text">外送服務費</div>
            <div class="price">$0</div>
        </div>
    <hr>
        <div class="total-container">
            <h2>小計</h2>
            <p><?php echo $totalPrice?></p>
        </div>
    <hr>
    <div class="paybill-container">
        <form action="#" method="post" id="payment">
            <div class="user-info">
                <label for="user_name"><span>*</span>訂購人：<?php echo $theName?></label>
            </div>
            <div class="user-info">
                <label for="email"><span>*</span>電子信箱：<?php echo $theEmail?></label>
            </div>
            <div class="user-info">
                <label for="phone"><span>*</span>手機：<?php echo $thePhone?></label>
            </div>
            <div class="user-info">
                <label for="invoice"><span>*</span>發票類型</label>
            </div>
            <div>
                <input type="radio" id="general_invoice" name="invoice_method">
                <label for="general_invoice">一般發票</label>
            </div>
            <div>
                <input type="radio" id="electronic_invoice" name="invoice_method">
                <label for="electronic_invoice">電子發票</label>
            </div>
    </div>
        <div class="paybill-container">
            <div class="user-info">
                <label for="remark"><span>*</span>備註</label>
                <input type="text" id="remark" name="remark" maxlength="30" placeholder="*備註欄最多30字">
            </div>
        </div>
        <div class="paybill-container">
            <div class="header-text">
                <p>&nbsp&nbsp取餐方式/時間</p>
            </div>
            <div class="order-details">
                <h4>取餐方式：</h4>
                <p><?php echo $deliverString?></p>
                <h4>取餐門市：</h4>
                <p><?php echo $realAddress ?></p>
                <!-- <p>預計取餐時間：<?php echo $orderDate . $orderTIme?></p> -->
                <h4>預計取餐時間：</h4>
                <p><?php echo $orderDate . " " . $orderTIme?></p>
                <h4>選擇取餐時間：</h4>
                <input type="datetime-local" id="pickupTime" name="pickupTime" min="2023-12-18T00:00"></p>
            </div>
        </div>
        <div class="paybill-container">
            <div class="header-text">
                <p>&nbsp&nbsp付款方式</p>
            </div>
        </div>
        <hr>
        <div class="total-container">
            <h2>待付金額</h2>
            <p><?php echo $totalPrice?></p>
        </div>
        <hr>
        <div class="input-group">
            <input type="radio" id="credit_card" name="payment_method" onclick="showCreditCardInput()">
            <img src="https://storage.googleapis.com/kfcoosfs/credit_pay_icon.png">
            <label for="credit_card">信用卡</label>
        </div>
        <div class="input-group" id="creditCardInputContainer" style="display: none;">
                <label for="creditCardNumber">卡號：</label>
                <input type="text" id="creditCardNumber" name="creditCardNumber" maxlength="12" style="width: 200px;">
            </div>
        <div class="input-group">
            <input type="radio" id="line_pay" name="payment_method" onclick="hideCreditCardInput()">
            <img src="https://storage.googleapis.com/kfcoosfs/line_pay_icon.png">
            <label for="line_pay">Line Pay</label>
        </div>
        <div class="input-group">
            <input type="radio" id="cash" name="payment_method" onclick="hideCreditCardInput()">
            <img src="https://storage.googleapis.com/kfcoosfs/cash_pay_icon.png">
            <label for="cash">到店付款(現金、悠遊卡)</label>
        </div>
        <button class= "check-button" type="submit" name="order" id="checkoutButton">送出訂單</button>
    </form>
        <?php
            if (isset($_POST["order"])) {
                $remark = $_POST["remark"];
                $pickupTime = $_POST["pickupTime"];
                if ($pickupTime != null) {
                    list($orderDate, $orderTime) = explode("T", $pickupTime);
                    $updateSql = "UPDATE `customer_order` SET `order_date` = '$orderDate', `order_time` = '$orderTime', `note` = '$remark' WHERE `member_id` = '$theMemberid' AND `is_pay` = 0";
                } else {
                    $updateSql = "UPDATE `customer_order` SET `note` = '$remark' WHERE `member_id` = '$theMemberid' AND `is_pay` = 0";
                }
                mysqli_query($link, $updateSql);

                $paySql = "UPDATE `customer_order` SET `is_pay` = 1 WHERE `member_id` = '$theMemberid'";
                mysqli_query($link, $paySql);

                unset($_SESSION["restaurant_name"]);
                unset($_SESSION["orderDate"]);
                unset($_SESSION["orderTime"]);
                unset($_SESSION["mealName"]);
                unset($_SESSION["meal_deliver"]);

                echo "<script type='text/javascript'>alert('訂單已送出，祝您用餐愉快!'); window.location.href = 'index.php';</script>";
                exit();
            }
        ?>

        <script>
            function showCreditCardInput() {
                var creditCardInputContainer = document.getElementById("creditCardInputContainer");
                creditCardInputContainer.style.display = "block";
            }

            function hideCreditCardInput() {
                var creditCardInputContainer = document.getElementById("creditCardInputContainer");
                creditCardInputContainer.style.display = "none";
            }
        </script>
    </div>
    <script>
        function redirectToMenu(menuType) {
            const menuHtmlFiles = {
              '修改': 'cart.php',
            };
            const menuHtmlFile = menuHtmlFiles[menuType];
            if (menuHtmlFile) {
              window.location.href = menuHtmlFile;
            }
          }
    </script>
    <footer>
        &copy; 2023 Software Term Project
    </footer>
</body>
</html>
