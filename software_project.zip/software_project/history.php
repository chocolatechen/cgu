

<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="Style_history.css">
  <title>肯德基登入系統</title>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('購物車')">購物車</button> <!-- 添加這裡的購物車按鈕 -->
      </div>

      <div class="container">
        <div class="login-form">
          <h2>訂單紀錄</h2>
          <div class="order-summary">
            所有訂單 共3筆紀錄
          </div>
    
          <div class="order-record">
            <div class="order-details">
              <p>訂餐時間: 2023-01-01 12:00 PM</p>
              <p>取餐時間: 2023-01-01 1:00 PM</p>
              <p>餐點名稱/數量:麥克雞塊套餐 x 1</p>
              <p>訂餐金額: $173</p>
            </div>
            <hr>
          </div>
    
          <div class="order-record">
            <div class="order-details">
              <p>訂餐時間: 2023-01-02 1:30 PM</p>
              <p>取餐時間: 2023-01-02 2:30 PM</p>
              <p>餐點名稱/數量: 多人歡聚餐 x 1</p>
              <p>訂餐金額: $255</p>
            </div>
            <hr>
          </div>
    
          <div class="order-record">
            <div class="order-details">
              <p>訂餐時間: 2023-01-03 2:45 PM</p>
              <p>取餐時間: 2023-01-03 3:45 PM</p>
              <p>餐點名稱/數量: 可樂 x 1</p>
              <p>訂餐金額: $15</p>
            </div>
          </div>
        </div>
      </div>
      
      
      <div class="center-buttons-and-current-page">
        <button type="button" class="action-button" onclick="location.href='history.php'">  
            <div class="current-page">
            <span id="currentPageLabel">訂單資料</span>
        </div></button>
        <button type="button" class="action-button" onclick="location.href='profile.php'">
            個人資料
        </button>

        <div class="separator"></div>
        <button type="button" class="action-button" onclick="logout()">
            登出
        </button>
      </div>
      <script>
        function logout() {
          // 使用 AJAX 请求执行登出操作
          var xhr = new XMLHttpRequest();
          xhr.open("POST", "logout.php", true);
          xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

          xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
              // 登出成功后，跳转到首页
              window.location.href = 'index.php';
            }
          };

          xhr.send();
        }
      </script>
      
