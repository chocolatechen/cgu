

<!DOCTYPE html>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="Style_history.css">
  <title>肯德基登入系統</title>
</head>

<body>
    <div class="header">
        <div class="logo-container">
            <button type="button" class="logo-button" onclick="location.href='your_link_here'">
                <img src="KFC_image.jpg" class="logo">
            </button>
        </div>
    
        <div class="logo-container">
            <button type="button" class="logo-button" onclick="location.href='your_link_here'">
                <img src="head.jpg" class="logo">
            </button>
        </div>
    </div>

      <div>
      <div class="container">
        <div class="login-form">
            <h2>餐點內容</h2>
          <div class="order-record">
            <div class="order-details">
              <p>花生熔岩咔啦雞腿堡XL套餐</p>
              <button onclick="modifyOrder()">修改</button><button onclick="modifyOrder()">刪除</button>
              <p>花生熔岩咔啦雞腿堡(辣) x 1</p>
              <p>咔啦脆雞(辣) x 1</p>
              <p>原味蛋撻 x 1</p>
              <p>香酥脆薯(中) x 1</p>
              <p>百事可樂(中) x 1</p>
            </div>
            <hr>
          </div>
        </div>
      </div>

    
      <div id="shoppingBagContainer">
        <label for="shoppingBagCheckbox">要不要購物袋</label>
        <input name="shoppingBagCheckbox" type="checkbox" id="shoppingBagCheckbox" onchange="updateTotalAmount()">
    
        <div class="addTitle">
            若訂購餐點份數較多，建議加購購物袋。
        </div>
        <label for="quantity">購物袋數量:</label>
        <input type="number" id="quantity" min="0" value="0" onchange="updateTotalAmount()">
      </div>
      <div id="totalAmount">
        <style>
            .total-amount {
                font-size: 130%; /* 設置字體大小為原大小的120% */
            }
        </style>
      <hr>
        <p class="total-amount">總計$ 235</p>
      <hr>
      </div>
    
      <button name="pay" type="submit" id="checkoutButton" onclick="checkout()">立即結帳</button>
    
  <script>
    function updateTotalAmount() {
      var totalAmountElement = document.getElementById('totalAmount');
      var shoppingBagCheckbox = document.getElementById('shoppingBagCheckbox');
      var quantityInput = document.getElementById('quantity');

       var baseAmount = 0; 
      var additionalAmount = shoppingBagCheckbox.checked ? (1.00 * quantityInput.value) : 0.00;
      var totalAmount = baseAmount + additionalAmount;

      totalAmountElement.textContent = '總計$' + totalAmount.toFixed(2);
    }
    function checkout() {
    window.location.href = 'paybill.php';
  }
  </script>
    </body>
    </html>