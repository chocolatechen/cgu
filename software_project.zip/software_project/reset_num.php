<?php
include 'db.php';
session_start();

ini_set('display_errors', '1');

if (isset($_POST["sendBt"])) {
    $user = isset($_SESSION['phone']) ? $_SESSION['phone'] : null;
    if ($user) {
        $userPhone = $user;

        // Get the new password and confirm password from the form
        $newPassword = mysqli_real_escape_string($link, $_POST['NewPassword']);
        $confirmPassword = mysqli_real_escape_string($link, $_POST['ConfirmPassword']);

        // Check if the new password and confirm password match
        if ($newPassword === $confirmPassword) {
            // Update the password in the database based on the provided user_account
            $updateSql = "UPDATE `user_info` SET `user_password` = '$newPassword' WHERE `phone` = $userPhone";
            $updateResult = mysqli_query($link, $updateSql);

            if ($updateResult) {
                unset($_SESSION['phone']);
                echo "<script type='text/javascript'>alert('密碼修改成功!'); window.location.href = 'login.php';</script>";
            } else {
                $alert = "密碼修改失敗!";
                echo "<script type='text/javascript'>alert('$alert');</script>";
            }
        } else {
            $alert = "新密碼和確認密碼不相同!";
            echo "<script type='text/javascript'>alert('$alert');</script>";
        }
    } else {
        $alert = "未找到用戶信息!";
        echo "<script type='text/javascript'>alert('$alert');</script>";
    }
}
mysqli_close($link);
?>


<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="Style_test.css">
  <title>肯德基登入系統</title>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
      </div>
      <script>
        function redirectToMenu(menuType) {
            const menuHtmlFiles = {
            '個人餐': 'personal_meal.php',
            '多人餐': 'family_meal.php',
            '早餐': 'breakfast.php',
            '單點': 'single_item.php',
            };
            const menuHtmlFile = menuHtmlFiles[menuType];
            if (menuHtmlFile) {
            window.location.href = menuHtmlFile;
            }
        }
      </script>

  <div class="container">
    <div class="login-form">
      <h1>修改密碼</h1>

      <form autocomplete="off" action="reset_num.php" method="post">
        <div id="passwordChangeForm">
            <label for="NewtxtPassword">新密碼:</label>
            <input type="password" id="txtPassword" name="NewPassword" placeholder="請輸入密碼">

            <label for="txtConfirmPassword">確認密碼:</label>
            <input type="password" id="txtConfirmPassword" name="ConfirmPassword" placeholder="請再次輸入密碼">

            <button type="submit" class="btn block" id="btnsend" name="sendBt"><span>確認送出</span></button>
        </div>
      </form>
    </div>
  </div>

    
       
</body>
</html>