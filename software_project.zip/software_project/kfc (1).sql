-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2023-12-20 14:54:52
-- 伺服器版本： 8.0.17
-- PHP 版本： 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `kfc`
--

-- --------------------------------------------------------

--
-- 資料表結構 `customer_order`
--

CREATE TABLE `customer_order` (
  `id` int(11) NOT NULL COMMENT '流水編號',
  `member_id` int(11) NOT NULL COMMENT '會員編號',
  `customer_name` varchar(10) COLLATE utf8mb4_general_ci NOT NULL COMMENT '訂餐者名稱',
  `restaurant_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '訂餐餐廳名稱',
  `order_date` date NOT NULL COMMENT '訂餐日期',
  `order_time` time NOT NULL COMMENT '訂餐時間',
  `meal_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '訂購的餐點名稱',
  `num_meal` int(11) NOT NULL COMMENT '訂購的餐點數量',
  `extra_order_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '額外加點的品項名稱',
  `meal_deliver` tinyint(1) NOT NULL COMMENT '預定快取或外送服務',
  `total_price` int(11) NOT NULL COMMENT '訂單總金額',
  `note` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '訂單備註',
  `is_pay` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '是否結完帳',
  `shopping_bag` int(4) UNSIGNED NOT NULL DEFAULT '0' COMMENT '購物袋購買數量'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `customer_order`
--

INSERT INTO `customer_order` (`id`, `member_id`, `customer_name`, `restaurant_name`, `order_date`, `order_time`, `meal_name`, `num_meal`, `extra_order_name`, `meal_deliver`, `total_price`, `note`, `is_pay`, `shopping_bag`) VALUES
(1, 1, 'chocolate', '台北承德餐廳', '2023-12-20', '21:41:00', '花生熔岩咔啦雞腿堡XL套餐', 1, NULL, 1, 235, 'qweqw', 1, 0),
(2, 1, 'chocolate', '台北承德餐廳', '2023-12-20', '21:41:00', '青花椒香麻咔啦雞腿堡XL套餐', 1, NULL, 1, 220, 'qweqw', 1, 0);

-- --------------------------------------------------------

--
-- 資料表結構 `customize_meals`
--

CREATE TABLE `customize_meals` (
  `id` int(11) NOT NULL COMMENT '流水編號',
  `customize_meal_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每個餐點內可客製化的小品項',
  `can_change_meal_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '可更換品項名稱',
  `price_diff` int(11) NOT NULL COMMENT '可更換的價差'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `customize_meals`
--

INSERT INTO `customize_meals` (`id`, `customize_meal_name`, `can_change_meal_name`, `price_diff`) VALUES
(1, '香酥脆薯(中)', '香酥脆薯(大)', 10),
(2, '原味蛋撻', '鹽之花可可蛋撻', 8),
(3, '百事可樂(中)', '玉米濃湯(小)', 3),
(4, '百事可樂(中)', '玉米濃湯(大)', 15),
(5, '百事可樂(中)', '冰義式咖啡', 32),
(6, '百事可樂(中)', '冰義式拿鐵', 43),
(7, '百事可樂(中)', '熱義式咖啡(小)', 0),
(8, '百事可樂(中)', '熱義式咖啡(大)', 12),
(9, '百事可樂(中)', '熱義式拿鐵', 38),
(10, '百事可樂(中)', '經典冰奶茶', 1),
(11, '百事可樂(中)', '經典熱奶茶(小)', 0),
(12, '百事可樂(中)', '經典熱奶茶(中)', 1),
(13, '咔啦脆雞(辣)', '青花椒香麻脆雞(辣)', 3),
(14, '咔啦脆雞(辣)', '楓糖香蒜脆雞(辣)', 3),
(15, '香酥脆薯(小)', '香酥脆薯(中)', 12),
(16, '香酥脆薯(小)', '香酥脆薯(大)', 21),
(17, '玉米濃湯(小)', '玉米濃湯(大)', 12),
(18, '玉米濃湯(小)', '冰義式咖啡', 29),
(19, '玉米濃湯(小)', '冰義式拿鐵', 40),
(20, '玉米濃湯(小)', '熱義式咖啡(小)', 0),
(21, '玉米濃湯(小)', '熱義式咖啡(大)', 9),
(22, '玉米濃湯(小)', '熱義式拿鐵', 35),
(23, '玉米濃湯(小)', '經典冰奶茶', 0),
(24, '玉米濃湯(小)', '經典熱奶茶(中)', 0),
(25, '玉米濃湯(小)', '百事可樂(中)', 0),
(26, '經典玉米', '香酥脆薯(小)', 0),
(27, '百事可樂(小)', '玉米濃湯(小)', 9),
(28, '百事可樂(小)', '玉米濃湯(大)', 21),
(29, '百事可樂(小)', '冰義式咖啡', 38),
(30, '百事可樂(小)', '冰義式拿鐵', 49),
(31, '百事可樂(小)', '熱義式咖啡(小)', 5),
(32, '百事可樂(小)', '熱義式咖啡(大)', 18),
(33, '百事可樂(小)', '熱義式拿鐵', 44),
(34, '百事可樂(小)', '經典冰奶茶', 7),
(35, '百事可樂(小)', '經典熱奶茶(小)', 4),
(36, '百事可樂(小)', '經典熱奶茶(中)', 7),
(37, '百事可樂(小)', '百事可樂(中)', 6),
(38, '咔啦雞腿堡(辣)', '紐奧良烤腿堡', 2),
(39, '咔啦雞腿堡(辣)', '青花椒香麻咔啦雞腿堡', 10),
(40, '咔啦雞腿堡(辣)', '花生熔岩咔啦雞腿堡(辣)', 25),
(41, '經典熱奶茶(小)', '玉米濃湯(小)', 5),
(42, '經典熱奶茶(小)', '玉米濃湯(大)', 17),
(43, '經典熱奶茶(小)', '冰義式咖啡', 34),
(44, '經典熱奶茶(小)', '冰義式拿鐵', 45),
(45, '經典熱奶茶(小)', '熱義式咖啡(小)', 1),
(46, '經典熱奶茶(小)', '熱義式咖啡(大)', 14),
(47, '經典熱奶茶(小)', '熱義式拿鐵', 40),
(48, '經典熱奶茶(小)', '經典冰奶茶', 3),
(49, '經典熱奶茶(小)', '經典熱奶茶(中)', 3),
(50, '經典熱奶茶(小)', '百事可樂(小)', 0),
(51, '經典熱奶茶(小)', '百事可樂(中)', 2);

-- --------------------------------------------------------

--
-- 資料表結構 `extra_order`
--

CREATE TABLE `extra_order` (
  `id` int(11) NOT NULL COMMENT '流水編號',
  `extra_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每個可加點品項的名稱',
  `name_en` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每個可加點品項的英文名稱',
  `price` int(11) NOT NULL COMMENT '每個可加點品項的價格',
  `image` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每個可加點品項的照片路徑'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `meals`
--

CREATE TABLE `meals` (
  `id` int(11) NOT NULL COMMENT '流水編號',
  `meal_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每種餐點的名稱',
  `name_en` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每種餐點的英文名稱',
  `price` int(11) NOT NULL COMMENT '每種餐點的價格',
  `image` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每種餐點的照片路徑',
  `detail` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL COMMENT '每種餐點的細項介紹',
  `meal_type` int(11) NOT NULL COMMENT '每種餐點屬於的分類，分類有(個人餐、多人餐，早餐，單點)',
  `series` int(11) NOT NULL COMMENT '每種餐點屬於的系列，系列有(XL套餐、L套餐、M套餐、S套餐、上校私廚沙拉、2~4歡聚餐、5~7歡聚餐、早餐套餐、早餐單點、單點主餐、蛋塔、附餐/點心、飲料/湯品)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `meals`
--

INSERT INTO `meals` (`id`, `meal_name`, `name_en`, `price`, `image`, `detail`, `meal_type`, `series`) VALUES
(1, '楓糖香蒜脆雞XL超豪肯餐', 'Maple garlic glazed Fried Chicken XL Combo', 235, 'https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-XL-20231127.jpg', '[1] 楓糖香蒜脆雞(辣)x2 (2pcs Maple garlic glazed Fried Chicken) [2] 上校雞塊x4 (4pcs Nuggets) [3] 香酥脆薯(中)x1 (Crispy Fries(M)) [4] 原味蛋撻x1 (Original Egg Tart) [5] 百事可樂(中)x1 (Pepsi(M))', 1, 1),
(2, '剝皮辣椒紙包雞XL套餐', 'Peeled chili pepper Foilicious XL Combo', 239, 'https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-XL-20231019.jpg', '[1] 剝皮辣椒紙包雞x1 (Peeled chili pepper Foilicious) [2] 雞汁風味飯x1 (Chicken Flavored Rice) [3] 上校雞塊x4 (4pcs Nuggets) [4] 原味蛋撻x1 (Original Egg Tart) [5] 百事可樂(中)x1 (Pepsi(M))', 1, 1),
(3, '青花椒香麻脆雞XL套餐', 'Green Pepper Fried Chicken XL Combo', 235, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-XL%E9%A4%90-%E9%9D%92%E8%8A%B1%E6%A4%92%E9%BA%BB%E9%9B%9E20221215.jpg', '[1] 青花椒香麻脆雞(辣)x2 (2pcs Green Pepper Fried Chicken) [2] 上校雞塊x4 (4pcs Nuggets) [3] 香酥脆薯(中)x1 (Crispy Fries(M)) [4] 原味蛋撻x1 (Original Egg Tart) [5] 百事可樂(中)x1 (Pepsi(M))', 1, 1),
(4, '青花椒香麻咔啦雞腿堡XL套餐', 'Peeled chili pepper Foilicious XL Combo', 239, 'https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E5%8D%A1%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A1XL%E9%A4%9020220518.jpg', '[1] 青花椒香麻咔啦雞腿堡x1 (Green Pepper Zinger) [2] 咔啦脆雞(辣)x1 (Hot & Spicy) [3] 原味蛋撻x1 (Original Egg Tart) [4] 香酥脆薯(中)x1 (Crispy Fries(M)) [5] 百事可樂(中)x1 (Pepsi(M))', 1, 1),
(5, '花生熔岩咔啦雞腿堡XL套餐', 'Peanut Lava Zinger XL Combo', 235, 'https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E7%86%94%E5%B2%A9%E9%9B%9E%E8%85%BF%E5%A0%A1XL%E9%A4%9020220518.jpg', '[1] 花生熔岩咔啦雞腿堡(辣)X1 (Peanut Lava Zinger(spicy)) [2] 咔啦脆雞(辣)x1 (Hot & Spicy) [3] 香酥脆薯(中)x1 (Crispy Fries(M)) [4] 原味蛋撻x1 (Original Egg Tart) [5] 百事可樂(中)x1 (Pepsi(M))', 1, 1),
(6, '楓糖香蒜脆雞L絕配餐', 'Maple garlic glazed Fried Chicken L Combo', 195, 'https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-L-20231201.jpg', '[1] 楓糖香蒜脆雞(辣)x2 (2pcs Maple garlic glazed Fried Chicken) [2] 香酥脆薯(小)x1 (Crispy Fries(S)) [3] 百事可樂(中)x1 (Pepsi(M)) [4] 原味蛋撻x1 (Original Egg Tart)', 1, 2),
(7, '剝皮辣椒紙包雞L絕配餐', 'Peeled chili pepper Foilicious L Combo', 205, 'https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-L-20231019.jpg', '[1] 剝皮辣椒紙包雞x1 (Peeled chili pepper Foilicious) [2] 雞汁風味飯x1 (Chicken Flavored Rice) [3] 原味蛋撻x1 (Original Egg Tart) [4] 百事可樂(中)x1 (Pepsi(M))', 1, 2),
(8, '青花椒香麻脆雞絕配餐', 'Green Pepper Fried Chicken L Combo', 195, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-L%E9%A4%90-%E9%9D%92%E8%8A%B1%E6%A4%92%E9%BA%BB%E9%9B%9E20221214.jpg', '[1] 青花椒香麻脆雞(辣)x2 (2pcs Green Pepper Fried Chicken) [2] 香酥脆薯(小)x1 (Crispy Fries(S)) [3] 百事可樂(中)x1 (Pepsi(M)) [4] 原味蛋撻x1 (Original Egg Tart)', 1, 2),
(9, '青花椒咔啦雞腿堡絕配餐', 'Green Pepper Zinger L combo', 170, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-L%E9%A4%90-%E9%9D%92%E8%8A%B1%E6%A4%92%E5%92%94%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A120221214.jpg', '[1] 青花椒香麻咔啦雞腿堡x1 (Green Pepper Zinger) [2] 香酥脆薯(小)x1 (Crispy Fries(S)) [3] 百事可樂(中)x1 (Pepsi(M)) [4] 原味蛋撻x1 (Original Egg Tart)', 1, 2),
(10, '咔啦雞腿堡絕配餐', 'Zinger L Combo', 160, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-L%E9%A4%90-%E5%92%94%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A120221214.jpg', '[1] 咔啦雞腿堡(辣)x1 (Zinger) [2] 香酥脆薯(小)x1 (Crispy Fries(S)) [3] 百事可樂(中)x1 (Pepsi(M)) [4] 原味蛋撻x1 (Original Egg Tart)', 1, 2),
(11, '楓糖香蒜脆雞M經典餐', 'Maple garlic glazed Fried Chicken M Combo', 181, 'https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-M-20231127.jpg', '[1] 楓糖香蒜脆雞(辣)x2 (2pcs Maple garlic glazed Fried Chicken) [2] 香酥脆薯(中)x1 (Crispy Fries(M)) [3] 百事可樂(中)x1 (Pepsi(M))', 1, 3),
(12, '剝皮辣椒紙包雞M經典餐', 'Peeled chili pepper Foilicious M Combo', 185, 'https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-M-20231019.jpg', '[1] 剝皮辣椒紙包雞x1 (Peeled chili pepper Foilicious) [2] 雞汁風味飯x1 (Chicken Flavored Rice) [3] 百事可樂(中)x1 (Pepsi(M)', 1, 3),
(13, '青花椒香麻脆雞經典餐', 'Green Pepper Fried Chicken Combo', 181, 'https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E9%A6%99%E9%BA%BB%E8%84%86%E9%9B%9E%E5%80%8B%E4%BA%BA%E9%A4%9020220901.jpg', '[1] 青花椒香麻脆雞(辣)x2 (2pcs Green Pepper Fried Chicken) [2] 香酥脆薯(中)x1 (Crispy Fries(M)) [3] 百事可樂(中)x1 (Pepsi(M))', 1, 3),
(14, '青花椒香麻咔啦雞腿堡經典餐', 'Green Pepper Zinger combo', 157, 'https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E5%8D%A1%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A1%E9%A4%9020220518.jpg', '[1] 青花椒香麻咔啦雞腿堡x1 (Green Pepper Zinger) [2] 香酥脆薯(中)x1 (Crispy Fries(M)) [3] 百事可樂(中)x1 (Pepsi(M))', 1, 3),
(15, '美式煙燻咔脆雞堡經典餐', 'Smoked Crispy Chincken Burger M Combo', 134, 'https://kfcoosfs.kfcclub.com.tw/%E7%BE%8E%E5%BC%8F%E7%85%99%E7%87%BB%E5%92%94%E8%84%86%E9%9B%9E%E5%A0%A1-%E7%B6%93%E5%85%B8%E9%A4%9020230208.jpg', '[1] 美式煙燻咔脆雞堡x1 (Smoked Crispy Chincken Burger) [2] 香酥脆薯(中)x1 (Crispy Fries(M)) [3] 百事可樂(中)x1 (Pepsi(M))', 1, 3),
(16, '美式煙燻咔脆雞堡雞勵餐', 'Smoked Crispy Chincken Burger S Combo', 109, 'https://kfcoosfs.kfcclub.com.tw/%E7%BE%8E%E5%BC%8F%E7%85%99%E7%87%BB%E5%92%94%E7%BE%8E%E5%BC%8F%E7%85%99%E7%87%BB%E5%92%94%E8%84%86%E9%9B%9E%E5%A0%A1-%E9%9B%9E%E5%8B%B5%E9%A4%9020230208.jpg', '[1] 美式煙燻咔脆雞堡x1 (Smoked Crispy Chincken Burger) [2] 百事可樂(小)x1 (Pepsi(S))', 1, 4),
(17, '咔啦酥脆雞勵餐', 'Chrisy S combo', 109, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E5%92%94%E5%95%A6%E9%85%A5%E8%84%86%E9%A4%9020221214.jpg', '[1] 咔啦脆雞(辣)x1 (Hot & Spicy)) [2] 上校雞塊x2 (2pcs Nuggets) [3] 百事可樂(小)x1 (Pepsi(S))', 1, 4),
(18, '8塊上校雞塊雞勵餐', '8pcs Nuggets S combo', 99, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-8%E5%A1%8A%E4%B8%8A%E6%A0%A1%E9%9B%9E%E5%A1%8A%E9%A4%90%E9%9B%9E%E5%8B%B5%E9%A4%9020221215.jpg', '[1] 上校雞塊x8 (8pcs Nuggets) [2] 百事可樂(小)x1 (Pepsi(S))', 1, 4),
(19, '原味起司燻雞捲雞勵餐', 'Original cheese & smoked chicken twister S combo', 99, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E5%8E%9F%E5%91%B3%E8%B5%B7%E5%8F%B8%E7%87%BB%E9%9B%9E%E6%8D%B2%E9%9B%9E%E5%8B%B5%E9%A4%9020221215.jpg', '[1] 原味起司燻雞捲x1 (Original cheese & smoked chicken twister) [2] 百事可樂(小)x1 (Pepsi(S))', 1, 4),
(20, '花生起司雞柳捲雞勵餐', 'Peanut & cheese chicken Twister S combo', 99, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E8%8A%B1%E7%94%9F%E8%B5%B7%E5%8F%B8%E9%9B%9E%E6%9F%B3%E6%8D%B2%E9%9B%9E%E5%8B%B5%E9%A4%9020221215.jpg', '[1] 花生起司雞柳捲x1 (Peanut & cheese chicken Twister) [2] 百事可樂(小)x1 (Pepsi(S))', 1, 4),
(21, '上校私廚烤雞腿溫沙拉套餐', 'Margherita Warm Salad Combo', 178, 'https://kfcoosfs.kfcclub.com.tw/%E7%83%A4%E9%9B%9E%E6%BA%AB%E6%B2%99%E6%8B%89%E5%A5%97%E9%A4%90(%E4%B8%8D%E9%81%A9%E7%94%A8%E5%A4%96%E9%80%81)-210927.jpg', '[1] 上校私廚烤雞腿溫沙拉x1 (Margherita Warm Salad) [2] 玉米濃湯(小)x1 (Corn Soup(247g))', 1, 5),
(22, '凱薩烤地瓜沙拉套餐', 'Caesar Sweet Potato Salad Combo', 164, 'https://kfcoosfs.kfcclub.com.tw/%E5%87%B1%E8%96%A9%E7%83%A4%E5%9C%B0%E7%93%9C%E6%B2%99%E6%8B%89%E5%A5%97%E9%A4%9020220519.jpg', '[1] 凱薩烤地瓜沙拉x1 (Caesar Sweet Potato Salad) [2] 經典玉米x1 (Classic Corn) [3] 百事可樂(中)x1 (Pepsi(M))', 1, 5),
(23, '上校私廚烤雞腿溫沙拉', 'Margherita Warm Salad ALC', 135, 'https://kfcoosfs.kfcclub.com.tw/%E7%83%A4%E9%9B%9E%E6%BA%AB%E6%B2%99%E6%8B%89-%E5%96%AE%E9%BB%9E-211004.jpg', '[1] 上校私廚烤雞腿溫沙拉X1 (Margherita Warm Salad ALC)', 1, 5),
(24, '凱薩烤地瓜沙拉', 'Caesar Sweet Potato Salad', 129, 'https://kfcoosfs.kfcclub.com.tw/%E5%87%B1%E8%96%A9%E7%83%A4%E5%9C%B0%E7%93%9C%E6%B2%99%E6%8B%8920220518.jpg', '[1] 凱薩烤地瓜沙拉x1 (Caesar Sweet Potato Salad)', 1, 5),
(25, '楓糖香蒜脆雞同樂餐', 'Maple garlic glazed Fried Chicken Sharing Combo', 650, 'https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-%E5%90%8C%E6%A8%8220231127.jpg', '[1] 楓糖香蒜脆雞(辣)x4 (4pcs Maple garlic glazed Fried Chicken) [2] 咔啦脆雞(辣)x4 (4pcs Hot & Spicy)) [3] 上校雞塊x4 (4pcs Nuggets) [4] 香酥脆薯(中)x1 (Crispy Fries(M)) [5] 雙色轉轉QQ球x1 (Sweet Potato QQ Ball) [6] 原味蛋撻x6 (6pcs Original Egg Tart)', 2, 6),
(26, '楓糖香蒜脆雞雙人餐', 'Maple garlic glazed Fried Chicken Buddy Combo', 380, 'https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-%E9%9B%99%E4%BA%BA%E9%A4%9020231127.jpg', '[1] 楓糖香蒜脆雞(辣)x2 (2pcs Maple garlic glazed Fried Chicken) [2] 咔啦脆雞(辣)x2 (2pcs Hot & Spicy)) [3] 上校雞塊x4 (4pcs Nuggets) [4] 香酥脆薯(中)x1 (Crispy Fries(M)) [5] 原味蛋撻x2 (2pcs Original Egg Tart) [6] 百事可樂(中)x2 (2pcs Pepsi(M))', 2, 6),
(27, '剝皮辣椒紙包雞雙人餐', 'Peeled chili pepper Foilicious Buddy Combo', 380, 'https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-%E9%9B%99%E4%BA%BA%E9%A4%9020231019.jpg', '[1] 剝皮辣椒紙包雞x1 (Peeled chili pepper Foilicious) [2] 雞汁風味飯x1 (Chicken Flavored Rice) [3] 咔啦脆雞(辣)x2 (2pcs Hot & Spicy)) [4] 香酥脆薯(中)x1 (Crispy Fries(M)) [5] 原味蛋撻x2 (2pcs Original Egg Tart) [6] 百事可樂(中)x2 (2pcs Pepsi(M))', 2, 6),
(28, '青花椒狂嗑桶', 'Green Pepper Fried Chicken Crunchy bucket combo', 389, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E9%9D%92%E8%8A%B1%E6%A4%92%E7%8B%82%E5%97%91%E6%A1%B6_20220928.jpg', '[1] 青花椒香麻脆雞(辣)x5 (5pcs Green Pepper Fried Chicken) [2] 雙色轉轉QQ球x1 (Sweet Potato QQ Ball) [3] 原味蛋撻x2 (2pcs Original Egg Tart) [4] 百事可樂(小)x2 (2pcs Pepsi(S))', 2, 6),
(29, '青花椒香麻咔啦雞腿堡雙人餐', 'Green Pepper Zinger Buddy combo', 380, 'https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E9%A6%99%E9%BA%BB%E5%92%94%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A1%E9%9B%99%E4%BA%BA%E9%A4%9020220518.jpg', '[1] 青花椒香麻咔啦雞腿堡(辣)x1 (Green Pepper Zinger) [2] 青花椒香麻脆雞(辣)x2 (2pcs Green Pepper Fried Chicken) [3] 香酥脆薯(中)x1 (Crispy Fries(M)) [4] 上校雞塊x4 (4pcs Nuggets) [5] 雙色轉轉QQ球x1 (Sweet Potato QQ Ball) [6] 百事可樂(中)x2 (2pcs Pepsi(M))', 2, 6),
(30, '楓糖香蒜脆雞派對餐', 'Maple garlic glazed Fried Chicken Party Combo', 888, 'https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-%E6%B4%BE%E5%B0%8D%E9%A4%9020231127.jpg', '[1] 楓糖香蒜脆雞(辣)x6 (6pcs Maple garlic glazed Fried Chicken) [2] 咔啦脆雞(辣)x6 (6pcs Hot & Spicy)) [3] 香酥脆薯(中)x1 (Crispy Fries(M)) [4] 原味蛋撻x3 (3pcs Original Egg Tart) [5] 鹽之花可可蛋撻x3 (3pcs Fler de sel cocoa ET box) [6] 瓶可x1 (Pepsi(1.25L))', 2, 7),
(31, '剝皮辣椒紙包雞同樂餐', 'Peeled chili pepper Foilicious Sharing Combo', 920, 'https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-%E5%90%8C%E6%A8%82%E9%A4%9020231019.jpg', '[1] 剝皮辣椒紙包雞x3 (3pcs Peeled chili pepper Foilicious) [2] 雞汁風味飯x3 (3pcs Chicken Flavored Rice) [3] 咔啦脆雞(辣)x6 (6pcs Hot & Spicy)) [4] 原味蛋撻x6 (6pcs Original Egg Tart) [5] 瓶可x1 (Pepsi(1.25L))', 2, 7),
(32, '經典A餐-10塊雞桶', 'Classic A Bucket Combo 10pcs', 579, 'https://kfcoosfs.kfcclub.com.tw/%E7%B6%93%E5%85%B8A%E9%A4%90-10%E5%A1%8A%E9%9B%9E%E6%A1%B6-210726.jpg', '[1] 咔啦脆雞(辣)x10 (10pcs Hot & Spicy)) [2] 香酥脆薯(中)x2 (2pcs Crispy Fries(M))', 2, 7),
(33, '歡聚B餐-10塊雞', 'Party B Bucket Combo 10pcs', 795, 'https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E6%AD%A1%E8%81%9AB%E9%A4%90-10%E5%A1%8A%E9%9B%9E20221215.jpg', '[1] 咔啦脆雞(辣)x10 (10pcs Hot & Spicy)) [2] 上校雞塊x8 (8pcs Nuggets) [3] 雙色轉轉QQ球x1 (Sweet Potato QQ Ball) [4] 原味蛋撻x6 (6pcs Original Egg Tart) [5] 瓶可x1 (Pepsi(1.25L))', 2, 7),
(34, '超人氣同樂餐', 'Popular Sharing Combo', 924, 'https://kfcoosfs.kfcclub.com.tw/%E8%B6%85%E4%BA%BA%E6%B0%A3%E5%90%8C%E6%A8%82%E9%A4%9020220518.jpg', '[1] 咔啦脆雞(辣)x6 (6pcs Hot & Spicy)) [2] 咔啦雞腿堡(辣)x3 (Zinger) [3] 香酥脆薯(小)x3 (3pcs Crispy Fries(S)) [4] 原味蛋撻x6 (6pcs Original Egg Tart) [5] 瓶可x1 (Pepsi(1.25L))', 2, 7),
(35, '花生吮指嫩雞蛋堡套餐', 'Peanut Chicken Egg Burger Individual Combo', 79, 'https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1-%E5%A5%97%E9%A4%9020221115.jpg', '[1] 花生吮指嫩雞蛋堡x1 (Peanut Chicken Egg Burger) [2] 經典熱奶茶(小)x1 (Hot Milk Tea(200g))', 3, 8),
(36, '花生肉鬆嫩雞蛋堡套餐', 'Peanut Chicken & Meat Floss Burger Individual Combo', 79, 'https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%82%89%E9%AC%86%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1-%E5%A5%97%E9%A4%9020221115.jpg', '[1] 花生肉鬆嫩雞蛋堡x1 (Peanut Chicken & Meat Floss Burger) [2] 經典熱奶茶(小)x1 (Hot Milk Tea(200g))', 3, 8),
(37, '吮指嫩雞蛋堡套餐', 'Chicken Fillet Egg Burger Combo', 69, 'https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1%E5%A5%97%E9%A4%900724.jpg', '[1] 吮指嫩雞蛋堡x1 (Chicken Fillet Egg Burger) [2] 經典熱奶茶(小)x1 (Hot Milk Tea(200g))', 3, 8),
(38, '花生起司蛋堡套餐', 'Peanut Butter Cheese Egg Burger Individual Combo)', 49, 'https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%B5%B7%E5%8F%B8%E8%9B%8B%E5%A0%A1-%E5%A5%97%E9%A4%9020221115.jpg', '[1] 花生起司蛋堡x1 (Peanut Butter Cheese Egg Burger) [2] 經典熱奶茶(小)x1 (Hot Milk Tea(200g))', 3, 8),
(39, '吮指嫩雞蛋捲餅套餐', 'Chicken & Egg Twister Individual Combo', 85, 'https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E6%8D%B2%E9%A4%85-%E5%A5%97%E9%A4%9020221115.jpg', '[1] 吮指嫩雞蛋捲餅x1 (Chicken & Egg Twister)[2] 經典熱奶茶(小)x1 (Hot Milk Tea(200g))', 3, 8),
(40, '花生吮指嫩雞蛋堡', 'Peanut Chicken Egg Burger', 60, 'https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A120221115.jpg', '[1] 花生吮指嫩雞蛋堡x1 (Peanut Chicken Egg Burger)', 3, 9),
(41, '花生肉鬆嫩雞蛋堡', 'Peanut Chicken & Meat Floss Burger', 60, 'https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%82%89%E9%AC%86%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A120221115.jpg', '[1] 花生肉鬆嫩雞蛋堡x1 (Peanut Chicken & Meat Floss Burger)', 3, 9),
(42, '吮指嫩雞蛋堡', 'Chicken Fillet Egg Burger', 50, 'https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1.jpg', '[1] 吮指嫩雞蛋堡x1 (Chicken Fillet Egg Burger)', 3, 9),
(43, '花生起司蛋堡', 'Peanut Butter Cheese Egg Burger', 35, 'https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%B5%B7%E5%8F%B8%E8%9B%8B%E5%A0%A120221115.jpg', '[1] 花生起司蛋堡x1 (Peanut Butter Cheese Egg Burger)', 3, 9),
(44, '吮指嫩雞蛋捲餅', 'Chicken & Egg Twister', 66, 'https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E6%8D%B2%E9%A4%8520221115.jpg', '[1] 吮指嫩雞蛋捲餅x1 (Chicken & Egg Twister)', 3, 9),
(45, '楓糖香蒜脆雞', 'Maple garlic glazed Fried Chicken', 72, 'https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-%E5%96%AE%E9%BB%9E20231201.jpg', '[1] 楓糖香蒜脆雞(辣)x1 (Maple garlic glazed Fried Chicken)', 4, 10),
(46, '剝皮辣椒紙包雞', 'Peeled chili pepper Foilicious ALC', 148, 'https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-%E5%96%AE%E9%BB%9E-20231019.jpg', '[1] 剝皮辣椒紙包雞x1 (Peeled chili pepper Foilicious)', 4, 10),
(47, '美式燻雞咔脆雞堡', 'Smoked Crispy Chincken Burger', 99, 'https://kfcoosfs.kfcclub.com.tw/%E7%BE%8E%E5%BC%8F%E7%85%99%E7%87%BB%E5%92%94%E8%84%86%E9%9B%9E%E5%A0%A120230208.jpg', '[1] 美式煙燻咔脆雞堡x1 (Smoked Crispy Chincken Burger)', 4, 10),
(48, '青花椒香麻咔啦雞腿堡', 'Green Pepper Zinger', 125, 'https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E5%8D%A1%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A12022051801.jpg', '[1] 青花椒香麻咔啦雞腿堡x1 (Green Pepper Zinger)', 4, 10),
(49, '青花椒香麻脆雞(辣)', 'Green Pepper Fried Chicken', 72, 'https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E9%A6%99%E9%BA%BB%E8%84%86%E9%9B%9E%E5%96%AE%E9%BB%9E20220901.jpg', '[1] 青花椒香麻脆雞(辣)x1 (Green Pepper Fried Chicken)', 4, 10),
(50, '鹽之花可可蛋撻禮盒', 'Fler de sel cocoa ET box', 288, 'https://kfcoosfs.kfcclub.com.tw/%E9%87%91%E7%87%A6%E9%B9%BD%E4%B9%8B%E8%8A%B1%E5%8F%AF%E5%8F%AF%E8%9B%8B%E6%92%BB%E7%A6%AE%E7%9B%9220231127.jpg', '[1] 鹽之花可可蛋撻x6 (6pcs Fler de sel cocoa ET box)', 4, 11),
(51, '雙色蛋撻禮盒', 'Mixed ET box', 264, 'https://kfcoosfs.kfcclub.com.tw/%E9%87%91%E7%87%A6%E9%B9%BD%E4%B9%8B%E8%8A%B1%E5%8F%AF%E5%8F%AF%E8%9B%8B%E6%92%BB-%E9%9B%99%E8%89%B2%E8%9B%8B%E6%92%BB%E7%A6%AE%E7%9B%9220231127.jpg', '[1] 鹽之花可可蛋撻x3 (3pcs Fler de sel cocoa ET box) [2] 原味蛋撻x3 (3pcs Original Egg Tart)', 4, 11),
(52, '鹽之花可可蛋撻', 'Fler de sel cocoa ET', 53, 'https://kfcoosfs.kfcclub.com.tw/%E9%87%91%E7%87%A6%E9%B9%BD%E4%B9%8B%E8%8A%B1%E5%8F%AF%E5%8F%AF%E8%9B%8B%E6%92%BB-%E5%96%AE%E9%A1%8620231127.jpg', '[1] 鹽之花可可蛋撻x1 (Fler de sel cocoa ET box)', 4, 11),
(53, '原味蛋撻禮盒', 'Original Egg Tart Box', 240, 'https://kfcoosfs.kfcclub.com.tw/%E5%8E%9F%E5%91%B3%E8%9B%8B%E6%92%BB%E7%A6%AE%E7%9B%92.jpg', '[1] 原味蛋撻x1 (Original Egg Tart Box)', 4, 11),
(54, '原味蛋撻', 'Original Egg Tart', 45, 'https://kfcoosfs.kfcclub.com.tw/%E5%8E%9F%E5%91%B3%E8%9B%8B%E6%92%BB.jpg', '[1] 原味蛋撻x1 (Original Egg Tart Box)', 4, 11),
(55, '雙色轉轉QQ球', 'Sweet Potato QQ Ball', 50, 'https://kfcoosfs.kfcclub.com.tw/%E9%9B%99%E8%89%B2%E8%BD%89%E8%BD%89QQ%E7%90%83-20221024.jpg', '[1] 雙色轉轉QQ球x1 (Sweet Potato QQ Ball)', 4, 12),
(56, '單點上校雞塊4塊', '4 PCS Nuggets', 49, 'https://kfcoosfs.kfcclub.com.tw/%E4%B8%8A%E6%A0%A1%E9%9B%9E%E5%A1%8A4%E5%A1%8A.jpg', '[1] 上校雞塊x4 (4pcs Nuggets)', 4, 12),
(57, '經典玉米', 'Classic Corn', 33, 'https://kfcoosfs.kfcclub.com.tw/%E7%B6%93%E5%85%B8%E7%8E%89%E7%B1%B3.jpg', '[1] 經典玉米x1 (Classic Corn)', 4, 12),
(58, '香酥脆薯(小)', 'Crispy Fried(S)', 33, 'https://kfcoosfs.kfcclub.com.tw/%E9%A6%99%E9%85%A5%E8%84%86%E8%96%AF(%E5%B0%8F)-210726.jpg', '[1] 香酥脆薯(小)x1 (Crispy Fries(S))', 4, 12),
(59, '香酥脆薯(中)', 'Crispy Fried(M)', 49, 'https://kfcoosfs.kfcclub.com.tw/%E9%A6%99%E9%85%A5%E8%84%86%E8%96%AF(%E4%B8%AD)-210726.jpg', '[1] 香酥脆薯(小)x1 (Crispy Fries(M))', 4, 12),
(60, '香酥脆薯(大)', 'Crispy Fried(L)', 60, 'https://kfcoosfs.kfcclub.com.tw/%E9%A6%99%E9%85%A5%E8%84%86%E8%96%AF(%E5%A4%A7)-210726.jpg', '[1] 香酥脆薯(小)x1 (Crispy Fries(L))', 4, 12),
(61, '雞汁風味飯', 'Chicken Flavored Rice', 45, 'https://kfcoosfs.kfcclub.com.tw/%E9%9B%9E%E6%B1%81%E9%A2%A8%E5%91%B3%E9%A3%AF-210608.jpg', '[1] 雞汁風味飯x1 (Chicken Flavored Rice)', 4, 12),
(62, '玉米濃湯(小)', 'Corn Soup(247g)', 40, 'https://kfcoosfs.kfcclub.com.tw/%E7%8E%89%E7%B1%B3%E6%BF%83%E6%B9%AF(%E5%B0%8F)20220421.jpg', '[1] 玉米濃湯(小)x1 (Corn Soup(247g))', 4, 13),
(63, '玉米濃湯(大)', 'Corn Soup(325g)', 52, 'https://kfcoosfs.kfcclub.com.tw/%E7%8E%89%E7%B1%B3%E6%BF%83%E6%B9%AF(%E5%A4%A7)20220421.jpg', '[1] 玉米濃湯(大)x1 (Corn Soup(325g))', 4, 13),
(64, '冰義式咖啡', 'Iced Coffee', 69, 'https://kfcoosfs.kfcclub.com.tw/%E5%86%B0%E7%BE%A9%E5%BC%8F%E5%92%96%E5%95%A1.jpg', '[1] 冰義式咖啡x1 (Iced Coffee)', 4, 13),
(65, '冰義式拿鐵', 'Cafe Latte(290g)', 80, 'https://kfcoosfs.kfcclub.com.tw/%E5%86%B0%E7%BE%A9%E5%BC%8F%E6%8B%BF%E9%90%B5.jpg', '[1] 冰義式拿鐵x1 (Cafe Latte(290g))', 4, 13),
(66, '熱義式咖啡(小)', 'Hot Coffee(S)', 36, 'https://kfcoosfs.kfcclub.com.tw/%E7%86%B1%E7%BE%A9%E5%BC%8F%E5%92%96%E5%95%A1(%E5%B0%8F).jpg', '[1] 熱義式咖啡(小) (Hot Coffee(S))', 4, 13),
(67, '熱義式咖啡(大)', 'Hot Coffee(L)', 49, 'https://kfcoosfs.kfcclub.com.tw/%E7%86%B1%E7%BE%A9%E5%BC%8F%E5%92%96%E5%95%A1(%E5%A4%A7).jpg', '[1] 熱義式咖啡(大) (Hot Coffee(L))', 4, 13),
(68, '熱義式拿鐵', 'Hot Latte', 75, 'https://kfcoosfs.kfcclub.com.tw/%E7%86%B1%E7%BE%A9%E5%BC%8F%E6%8B%BF%E9%90%B5.jpg', '[1] 熱義式拿鐵 (Hot Latte)', 4, 13),
(69, '經典冰奶茶', 'Iced Milk Tea', 38, 'https://kfcoosfs.kfcclub.com.tw/%E7%B6%93%E5%85%B8%E5%86%B0%E5%A5%B6%E8%8C%B6(%E4%B8%AD).jpg', '[1] 經典冰奶茶 (Iced Milk Tea)', 4, 13),
(70, '經典熱奶茶(小)', 'Hot Milk Tea(200g)', 35, 'https://kfcoosfs.kfcclub.com.tw/%E7%B6%93%E5%85%B8%E7%86%B1%E5%A5%B6%E8%8C%B6(%E5%B0%8F).jpg', '[1] 經典熱奶茶(小) (Hot Milk Tea(200g))', 4, 13),
(71, '經典熱奶茶(中)', 'Hot Milk Tea(300g)', 38, 'https://kfcoosfs.kfcclub.com.tw/%E7%B6%93%E5%85%B8%E7%86%B1%E5%A5%B6%E8%8C%B6(%E4%B8%AD).jpg', '[1] 經典熱奶茶(中) (Hot Milk Tea(300g))', 4, 13),
(72, '瓶裝百事可樂', 'Pepsi(1.25L)', 45, 'https://kfcoosfs.kfcclub.com.tw/%E7%93%B6%E8%A3%9D%E5%8F%AF%E6%A8%82.jpg', '[1] 瓶裝百事可樂 (Pepsi(1.25L))', 4, 13),
(73, '百事可樂(小)', 'Pepsi(S)', 31, 'https://kfcoosfs.kfcclub.com.tw/%E7%99%BE%E4%BA%8B%E5%8F%AF%E6%A8%8220220105.jpg', '[1] 百事可樂(小) (Pepsi(S))', 4, 13),
(74, '百事可樂(中)', 'Pepsi(M)', 37, 'https://kfcoosfs.kfcclub.com.tw/%E7%99%BE%E4%BA%8B%E5%8F%AF%E6%A8%8220220105.jpg', '[1] 百事可樂(中) (Pepsi(M))', 4, 13);

-- --------------------------------------------------------

--
-- 資料表結構 `restaurant`
--

CREATE TABLE `restaurant` (
  `id` int(11) NOT NULL COMMENT '流水編號',
  `restaurant_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '餐廳名稱',
  `restaurant_city` varchar(10) COLLATE utf8mb4_general_ci NOT NULL COMMENT '餐廳所在縣市',
  `restaurant_area` varchar(10) COLLATE utf8mb4_general_ci NOT NULL COMMENT '餐廳所在地區',
  `restaurant_address` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '餐廳剩餘地址'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `restaurant`
--

INSERT INTO `restaurant` (`id`, `restaurant_name`, `restaurant_city`, `restaurant_area`, `restaurant_address`) VALUES
(1, '台北承德餐廳', '台北市', '大同區', '承德路一段38號'),
(2, '台北雙連餐廳', '台北市', '中山區', '民生西路9號'),
(3, '台北八德餐廳', '台北市', '中正區', '八德路一段64號'),
(4, '新北幸福餐廳', '新北市', '新莊區', '幸福路763之6號'),
(5, '三重重新二餐廳', '新北市', '三重區', '重新路二段1-1號'),
(6, '板橋新埔餐廳', '新北市', '板橋區', '文化路一段421巷2號1樓~3樓'),
(7, '林口復興餐廳', '桃園市', '龜山區', '復興一路110號'),
(8, '桃園中山二餐廳', '桃園市', '桃園區', '中山路444號'),
(9, '南崁中正餐廳', '桃園市', '蘆竹區', '中正路8號');

-- --------------------------------------------------------

--
-- 資料表結構 `user_info`
--

CREATE TABLE `user_info` (
  `member_id` int(11) NOT NULL COMMENT '會員編號',
  `user_sex` int(1) NOT NULL COMMENT '用戶性別，1表示男生，2表示女生',
  `user_password` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用戶的密碼',
  `phone` varchar(10) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用戶的手機號碼',
  `user_name` varchar(10) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用戶的姓名',
  `birthday` date NOT NULL COMMENT '用戶的生日',
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用戶的信箱帳號'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `user_info`
--

INSERT INTO `user_info` (`member_id`, `user_sex`, `user_password`, `phone`, `user_name`, `birthday`, `email`) VALUES
(1, 1, '0101', '0912345678', 'chocolate', '2003-01-01', 'B1029027@cgu.edu.tw'),
(2, 1, '0703', '0922345678', 'leo', '2003-07-03', 'B1029019@cgu.edu.tw'),
(3, 2, '0710', '0932345678', 'chien', '2003-07-10', 'B1029009@cgu.edu.tw'),
(4, 1, '0101', '0942345678', 'yu', '2003-01-01', 'B0922044cgu.edu.tw'),
(5, 1, '1234', '1233333333', 'wer', '2023-01-01', 'wer@cgu.edu.tw'),
(6, 1, '0101', '1242432423', 'sdfgsf', '2023-01-01', 'dfg@cgu.edu.tw'),
(7, 1, '1111', '1111111144', 'qew', '2023-01-01', 'qwe@cgu.edu.tw');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_name` (`customer_name`),
  ADD KEY `restaurant_name` (`restaurant_name`),
  ADD KEY `meal_name` (`meal_name`),
  ADD KEY `extra_order_name` (`extra_order_name`),
  ADD KEY `member_id` (`member_id`);

--
-- 資料表索引 `customize_meals`
--
ALTER TABLE `customize_meals`
  ADD PRIMARY KEY (`id`,`customize_meal_name`);

--
-- 資料表索引 `extra_order`
--
ALTER TABLE `extra_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `extra_name` (`extra_name`);

--
-- 資料表索引 `meals`
--
ALTER TABLE `meals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `meal_name` (`meal_name`);

--
-- 資料表索引 `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`id`),
  ADD KEY `restaurant_name` (`restaurant_name`);

--
-- 資料表索引 `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`member_id`),
  ADD UNIQUE KEY `phone` (`phone`,`email`),
  ADD KEY `user_name` (`user_name`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流水編號', AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `customize_meals`
--
ALTER TABLE `customize_meals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流水編號', AUTO_INCREMENT=52;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `extra_order`
--
ALTER TABLE `extra_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流水編號';

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `meals`
--
ALTER TABLE `meals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流水編號', AUTO_INCREMENT=75;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流水編號', AUTO_INCREMENT=10;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `user_info`
--
ALTER TABLE `user_info`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '會員編號', AUTO_INCREMENT=8;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `customer_order`
--
ALTER TABLE `customer_order`
  ADD CONSTRAINT `customer_order_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `user_info` (`member_id`),
  ADD CONSTRAINT `customer_order_ibfk_2` FOREIGN KEY (`customer_name`) REFERENCES `user_info` (`user_name`),
  ADD CONSTRAINT `customer_order_ibfk_3` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurant` (`restaurant_name`),
  ADD CONSTRAINT `customer_order_ibfk_4` FOREIGN KEY (`meal_name`) REFERENCES `meals` (`meal_name`),
  ADD CONSTRAINT `customer_order_ibfk_5` FOREIGN KEY (`extra_order_name`) REFERENCES `extra_order` (`extra_name`);

--
-- 資料表的限制式 `customize_meals`
--
ALTER TABLE `customize_meals`
  ADD CONSTRAINT `customize_meals_ibfk_1` FOREIGN KEY (`id`) REFERENCES `meals` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
