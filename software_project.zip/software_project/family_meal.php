<!DOCTYPE html>
<html lang="UTF-8">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="order.css">
  <title>肯德基登入系統</title>
  <script>
    function redirectToMenu(menuType) {
        const menuHtmlFiles = {
          '個人餐': 'personal_meal.php',
          '多人餐': 'family_meal.php',
          '早餐': 'breakfast.php',
          '單點': 'single_item.php',
        };
        const menuHtmlFile = menuHtmlFiles[menuType];
        if (menuHtmlFile) {
          window.location.href = menuHtmlFile;
        }
      }
      
      document.addEventListener("DOMContentLoaded", function () {
      const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
      
      genderOptions.forEach(function (option) {
        option.addEventListener('change', function () {
          updateRadioStyles();
        });
      });
  
      updateRadioStyles();
    });
  
    function updateRadioStyles() {
      const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
  
      genderOptions.forEach(function (option) {
        const label = option.nextElementSibling;
  
        if (option.checked) {
          label.classList.add('checked');
        } else {
          label.classList.remove('checked');
        }
      });
    }
  </script>
</head>
<body>
  <div class="navbar">
    <div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
  </div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
      <script>
          function checkLogin() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (!response.loggedIn) {
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
      </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button.active-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
    </div>
    <div>
        <ul>
          <li><a href="#2to4">2-4人歡聚餐</a></li>
          <li><a href="#5to7">5-7人歡聚餐</a></li>
        </ul>
    </div>
  </div>
  <script>
    function addToCart(button) {
        checkLogin();
        // 取得包含按鈕的 meals 元素
        var mealsElement = button.closest('.meals');
        
        // 從 meals 元素中取得餐點名稱
        var mealName = mealsElement.querySelector('h3').getAttribute('data-meal');

        // 使用 AJAX 向後端發送請求
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'addToCart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        // 將餐點名稱傳送到後端
        xhr.send('mealName=' + encodeURIComponent(mealName));

        // 等待後端回傳結果
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // 從後端回傳的資料中取得結果
                var result = xhr.responseText;
                if (result == "請先選擇餐廳、日期及時間") {
                  alert(result);
                  window.location.href = 'index.php';
                } else{
                  alert(result);
                  window.location.href = 'order_meal.php';
                }
                // 將結果顯示在前端
                // alert(result); // 這裡可以改成你希望的方式顯示回傳的文字
            }
        };
    }
  </script>
  <div class="content">
    <div id="2to4" class="section-container">
      <div class = "meals-title">2-4人歡聚餐</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-%E5%90%8C%E6%A8%8220231127.jpg" alt="2to4">
          <h3 data-meal="楓糖香蒜脆雞同樂餐">楓糖香蒜脆雞同樂餐</h4>
          <p>楓糖香蒜脆雞x4</p>
          <p>咔啦脆雞x4</p>
          <p>上校雞塊x4</p>
          <p>中薯*1</p>
          <p>QQ球*1</p>
          <p>原味蛋撻禮盒x1</p>
          <p class="meal-price">Price: $650</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-%E9%9B%99%E4%BA%BA%E9%A4%9020231127.jpg" alt="2to4">
          <h3 data-meal="楓糖香蒜脆雞雙人餐">楓糖香蒜脆雞雙人餐</h4>
          <p>楓糖香蒜脆雞(辣)x2</p>
          <p>咔啦脆雞(辣)x2</p>
          <p>上校雞塊x4</p>
          <p>香酥脆薯(中)x1</p>
          <p>原味蛋撻x2</p>
          <p>百事可樂(中)x2</p>
          <p class="meal-price">Price: $380</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-%E9%9B%99%E4%BA%BA%E9%A4%9020231019.jpg" alt="2to4">
          <h3 data-meal="剝皮辣椒紙包雞雙人餐">剝皮辣椒紙包雞雙人餐</h4>
          <p>剝皮辣椒紙包雞x1</p>
          <p>雞汁風味飯x1</p>
          <p>咔啦脆雞(辣)x2</p>
          <p>香酥脆薯(中)x1</p>
          <p>原味蛋撻x2</p>
          <p>百事可樂(中)x2</p>
          <p class="meal-price">Price: $380</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E9%9D%92%E8%8A%B1%E6%A4%92%E7%8B%82%E5%97%91%E6%A1%B6_20220928.jpg" alt="2to4">
          <h3 data-meal="青花椒狂嗑桶">青花椒狂嗑桶</h4>
          <p>青花椒香麻脆雞(辣)x5</p>
          <p>雙色轉轉QQ球x1</p>
          <p>原味蛋撻x2</p>
          <p>百事可樂(小)x2</p>
          <p class="meal-price">Price: $389</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E9%A6%99%E9%BA%BB%E5%92%94%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A1%E9%9B%99%E4%BA%BA%E9%A4%9020220518.jpg" alt="2to4">
          <h3 data-meal="青花椒香麻咔啦雞腿堡雙人餐">青花椒香麻咔啦雞腿堡雙人餐</h4>
          <p>青花椒香麻咔啦雞腿堡(辣)x1</p>
          <p>青花椒香麻脆雞(辣)x2</p>
          <p>香酥脆薯(中)x1</p>
          <p>上校雞塊x4</p>
          <p>雙色轉轉QQ球x1</p>
          <p>百事可樂(中)x2</p>
          <p class="meal-price">Price: 380</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
    <div id="5to7" class="section-container">
      <div class = "meals-title">5-7人歡聚餐</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-%E6%B4%BE%E5%B0%8D%E9%A4%9020231127.jpg" alt="X meals">
          <h3 data-meal="楓糖香蒜脆雞派對餐">楓糖香蒜脆雞派對餐</h3>
          <p>楓糖香蒜脆雞x6</p>
          <p>咔啦脆雞x6</p>
          <p>中薯x1</p>
          <p>雙色蛋撻禮盒x1</p> 
          <p>瓶可*1</p>
          <p class="meal-price">Price: $888</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-%E5%90%8C%E6%A8%82%E9%A4%9020231019.jpg" alt="X meals">
          <h3 data-meal="剝皮辣椒紙包雞同樂餐">剝皮辣椒紙包雞同樂餐</h3>
          <p>剝皮辣椒紙包雞x3</p>
          <p>雞汁風味飯x3</p>
          <p>咔啦脆雞(辣)x6</p>
          <p>原味蛋撻x6</p> 
          <p>瓶可x1</p>
          <p class="meal-price">Price: $920</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E7%B6%93%E5%85%B8A%E9%A4%90-10%E5%A1%8A%E9%9B%9E%E6%A1%B6-210726.jpg" alt="X meals">
          <h3 data-meal="經典A餐-10塊雞桶">經典A餐-10塊雞桶</h3>
          <p>咔啦脆雞(辣)x10</p>
          <p>香酥脆薯(中)x2</p>
          <p class="meal-price">Price: $579</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E6%AD%A1%E8%81%9AB%E9%A4%90-10%E5%A1%8A%E9%9B%9E20221215.jpg" alt="X meals">
          <h3 data-meal="歡聚B餐-10塊雞">歡聚B餐-10塊雞</h3>
          <p>咔啦脆雞(辣)x10</p>
          <p>上校雞塊x8</p>
          <p>雙色轉轉QQ球x1</p>
          <p>原味蛋撻x6</p> 
          <p>瓶可x1</p>
          <p class="meal-price">Price: $795</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%B6%85%E4%BA%BA%E6%B0%A3%E5%90%8C%E6%A8%82%E9%A4%9020220518.jpg" alt="X meals">
          <h3 data-meal="超人氣同樂餐">超人氣同樂餐</h3>
          <p>咔啦脆雞(辣)x6</p>
          <p>咔啦雞腿堡(辣)x3</p>
          <p>香酥脆薯(小)x3</p>
          <p>原味蛋撻x6</p> 
          <p>瓶可x1</p>
          <p class="meal-price">Price: $924</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
  </div>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const navbarLinks = document.querySelectorAll('.navbar a');
    
      window.addEventListener('scroll', function () {
        const scrollPosition = window.scrollY || document.documentElement.scrollTop;
    
        navbarLinks.forEach(function (link) {
          const targetId = link.getAttribute('href').substring(1);
          const targetElement = document.getElementById(targetId);
    
          if (targetElement) {
            const isInViewport = isElementInViewport(targetElement);
    
            if (isInViewport) {
              link.classList.add('active-link');
            } else {
              link.classList.remove('active-link');
            }
          }
        });
      });
    
      function isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    
        // Check if at least 50% of the element is visible
        return (
          rect.top >= 0 &&
          rect.left >= 0 &&
          rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
        );
      }
    });
    
  </script>
  <footer>
    &copy; 2023 Software Term Project
  </footer>
  
</body>
</html>