<?php
session_start();

// 清除用户账户的 session 数据
unset($_SESSION['member_id']);

// 返回成功响应
echo "Logout successful";
?>
