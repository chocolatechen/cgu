<?php
session_start();
include 'db.php';
?>

<?php
    ini_set('display_errors', '1');

    if (isset($_POST["saveBt"])) {
      $user_gender = ($_POST["Gender"] === "先生") ? 1 : 2;
      $user_password = $_POST["Password"];
      $phone = $_POST["MobilePhone"];
      $user_name = $_POST["Name"];
      $birthday = $_POST["Year"] . '-' . $_POST["Month"] . '-' . $_POST["Day"];
      $email = $_POST["Email"];
      $memberCaptcha= $_POST['authcode'];
      $confirmPassword = $_POST['ConfirmPassword'];

      $sql = "SELECT * FROM `user_info` WHERE `email` = '$email'";
      $result = mysqli_query($link, $sql);
      $rowCount = mysqli_num_rows($result);
      
      if (empty($user_gender) || empty($user_password) || empty($phone) || empty($user_name) || empty($birthday) || empty($email)) {
        $alert = "請填寫完整資料!";
        echo "<script type='text/javascript'>alert('$alert');</script>";
      } else if ($user_password != $confirmPassword) {
        $alert = "密碼錯誤!";
        echo "<script type='text/javascript'>alert('$alert');</script>";
      } else if ($rowCount > 0) {
        $alert = "電子信箱已經註冊過!";
        echo "<script type='text/javascript'>alert('$alert');</script>";
      } else if (isset($_REQUEST['authcode'])) {
        if ($memberCaptcha != $_SESSION['authcode']) {
          $alert = "驗證碼錯誤";
          echo "<script type='text/javascript'>alert('$alert');</script>";
        } else {
          $stmt = "INSERT INTO user_info (user_sex, user_password, phone, user_name, birthday, email) VALUES ('$user_gender', '$user_password', '$phone', '$user_name', '$birthday', '$email')";
          if (mysqli_query($link, $stmt)) {
            header("Location: login.php");
            $alert = "註冊成功!";
            echo "<script type='text/javascript'>
                    if(confirm('$alert')) {
                        window.location.href = 'login.php';
                    }
                  </script>";
          } else {
            echo "Error";
          }
        }
       }
       mysqli_free_result($result);      
     }
    mysqli_close($link);
?>

<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="Style_test.css">
  <title>肯德基登入系統</title>
  <script>
        function redirectToMenu(menuType) {
      const menuHtmlFiles = {
        '個人餐': 'personal_meal.php',
        '多人餐': 'family_meal.php',
        '早餐': 'breakfast.php',
        '單點': 'single_item.php',
      };
      const menuHtmlFile = menuHtmlFiles[menuType];
      if (menuHtmlFile) {
        window.location.href = menuHtmlFile;
      }
    }

    document.addEventListener("DOMContentLoaded", function () {
      document.getElementById("currentPageLabel").innerText = "忘記密碼";

      if (window.location.href.indexOf('your_login_link_here') !== -1) {
        document.getElementById("currentPageLabel").innerText = "會員登入";
        document.getElementById("currentPageLabel").classList.add("current-page-login-color");
      } else if (window.location.href.indexOf('your_forgot_password_link_here') !== -1) {
        document.getElementById("currentPageLabel").innerText = "忘記密碼";
        document.getElementById("currentPageLabel").classList.add("current-page-forgot-password-color");
      }
    });

    function checkMobile() {
        const mobileInput = document.getElementById("MobilePhone");
        const isValidMobile = /^\d{10}$/.test(mobileInput.value);

        if (isValidMobile) {
            const xhr = new XMLHttpRequest();
            const url = "check_mobile.php";
            const params = "mobile=" + mobileInput.value;

            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                const response = xhr.responseText;

                if (response === "duplicate") {
                alert("手機已經註冊過!");
                } else {
                document.getElementById("otherInfoContainer").style.display = "block";
                }
            }
            };

            xhr.send(params);
        } else {
            alert("手機格式錯誤!");
        }
}

    document.addEventListener("DOMContentLoaded", function () {
  const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
  
  genderOptions.forEach(function (option) {
    option.addEventListener('change', function () {
      updateRadioStyles();
    });
  });

  updateRadioStyles();
});

function updateRadioStyles() {
  const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');

  genderOptions.forEach(function (option) {
    const label = option.nextElementSibling;

    if (option.checked) {
      label.classList.add('checked');
    } else {
      label.classList.remove('checked');
    }
  });
}
  </script>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
      </div>

  <div class="container">
    <div class="login-form">
      <h1>加入會員</h1>

      <form autocomplete="off" action="sign_up.php" method="post">
        <div class="memberInputbox">
            <div class="input-wrapper">
            <input type="text" id="MobilePhone" name="MobilePhone" maxlength="10" placeholder="手機">
            </div>
            <button type="button" id="btnCheckMobile" class="btn white" onclick="checkMobile()">
            <span>檢查手機號碼</span>
            </button>
        </div>
        <div id="otherInfoContainer" style="display: none;">
            <label for="txtEmail">電子信箱:</label>
            <input type="email" id="txtEmail" name="Email" placeholder="請輸入電子信箱">

            <label for="txtPassword">密碼:</label>
            <input type="password" id="txtPassword" name="Password" placeholder="請輸入密碼">

            <label for="txtConfirmPassword">確認密碼:</label>
            <input type="password" id="txtConfirmPassword" name="ConfirmPassword" placeholder="請再次輸入密碼">

            <label for="txtName">姓名:</label>
            <input type="text" id="txtName" name="Name" placeholder="請輸入姓名">

            <label>性別:</label>
            <div class="gender-options">
            <input type="radio" id="male" name="Gender" value="先生">
            <label for="male">先生</label>
            
            <input type="radio" id="female" name="Gender" value="小姐">
            <label for="female">小姐</label>
            </div>
            
            <div id="birthdayContainer">
                <label for="ddlYear">生日:</label>
                <select id="ddlYear" name="Year">
                    <?php
                    $currentYear = date("Y");
                    $startYear = 1930;

                    for ($year = $currentYear; $year >= $startYear; $year--) {
                        echo '<option value_year="' . $year . '">' . $year . '</option>';
                    }
                    ?>
                </select>

                <label for="ddlMonth">月:</label>
                <select id="ddlMonth" name="Month">
                    <?php
                    for ($month = 1; $month <= 12; $month++) {
                        echo '<option value_month="' . $month . '">' . $month . '</option>';
                    }
                    ?>
                </select>

                <label for="ddlDay">日:</label>
                <select id="ddlDay" name="Day">
                    <?php
                    for ($day = 1; $day <= 31; $day++) {
                        echo '<option value_day="' . $day . '">' . $day . '</option>';
                    }
                    ?>
                </select>
            </div>
            <!-- <div>
                <label for="txtPhoneVerificationCode">手機驗證碼:</label>
                <input type="text" id="txtPhoneVerificationCode" name="PhoneVerificationCode" placeholder="請輸入手機驗證碼">
                <button type="button" class="btn white" onclick="requestPhoneVerificationCode()">
                <span>獲取手機驗證碼</span>
                </button>
            </div> -->
            
            <label for="txtCaptcha">驗證碼:</label>
            <input type="text" id="txtCaptcha" name="authcode" placeholder="請輸入驗證碼">   
            <div class="verification_code">
                <p>
                  <img id="captcha_img" border='1' src='./captcha.php?r=echo rand(); ?>' style="width:150px; height:40px" />
                </p>
                <button class="btn white" type="button" onclick="document.getElementById('captcha_img').src='./captcha.php?r='+Math.random()">
                    <span>刷新驗證碼</span>
                </button>
            </div>

            <button type="submit" class="btn block" id="btnSave" name="saveBt"><span>確認送出</span></button>
        </div>
        </div>
      </form>
  </div>
      
  <div class="center-buttons-and-current-page">
    <button type="button" class="action-button" onclick="location.href='login.php'">
        會員登入
    </button>
    <button type="button" class="action-button" onclick="location.href='forget.php'">
        忘記密碼
    </button>
    <button type="button" class="action-button" onclick="location.href='sign_up.php'">  
        <div class="current-page">
        <span id="currentPageLabel">加入會員</span>
    </div></button>
  </div>
       
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      document.getElementById("currentPageLabel").innerText = "加入會員";

      if (window.location.href.indexOf('login.php') !== -1) {
        document.getElementById("currentPageLabel").innerText = "會員登入";
        document.getElementById("currentPageLabel").classList.add("current-page-login-color");
      } else if (window.location.href.indexOf('forget.php') !== -1) {
        document.getElementById("currentPageLabel").innerText = "忘記密碼";
        document.getElementById("currentPageLabel").classList.add("current-page-forgot-password-color");
      } else if (window.location.href.indexOf('sign_up.php') !== -1) {
        document.getElementById("currentPageLabel").innerText = "加入會員";
        document.getElementById("currentPageLabel").classList.add("current-page-add-member-color");
      }
        
    });
  </script>
</body>
</html>