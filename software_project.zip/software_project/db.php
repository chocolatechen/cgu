<?php
    $hostname="localhost";
    $username="root";
    $password="";
    $database="kfc";
    $link = mysqli_connect($hostname,$username,$password,$database);
    if($link){
        mysqli_query($link, "SET NAMES utf8");
    }
    else{
        echo '無法連線mysql資料庫 :<br/>' . mysqli_connect_error();
    }
?>