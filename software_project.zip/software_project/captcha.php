<?php
// 設定 session，必須處於指令碼最頂部
session_start();

$image = imagecreatetruecolor(150, 25);  // 設定驗證碼圖片大小的函數

// 設定驗證碼顏色
$bgcolor = imagecolorallocate($image, 255, 255, 255); // #ffffff

// 區域填充
imagefill($image, 0, 0, $bgcolor);

// 設定變數
$captcha_code = "";

// 生成亂數字
for ($i = 0; $i < 4; $i++) {
    // 設定字型大小
    $fontsize = 5; // 使用 imageloadfont 時，字型大小通常較小

    // 設定字型顏色，隨機顏色
    $fontcolor = imagecolorallocate($image, 0, 0, 0); // 0-120深顏色

    // 設定數位
    $fontcontent = rand(0, 9);

    // .= 連續定義變數
    $captcha_code .= $fontcontent;

    // 設定座標
    $x = ($i * 150 / 4) + 15;
    $y = 5;

    // 使用 imageloadfont 內置字體
    imagestring($image, $fontsize, $x, $y, $fontcontent, $fontcolor);
}

// 存到 session
$_SESSION['authcode'] = $captcha_code;

// 增加干擾元素，設定雪花點
for ($i = 0; $i < 200; $i++) {
    // 設定點的顏色
    $pointcolor = imagecolorallocate($image, rand(50, 200), rand(50, 200), rand(50, 200));

    // 畫一個單一畫素
    imagesetpixel($image, rand(1, 149), rand(1, 29), $pointcolor);
}

// 增加干擾元素，設定橫線
for ($i = 0; $i < 4; $i++) {
    // 設定線的顏色
    $linecolor = imagecolorallocate($image, rand(80, 220), rand(80, 220), rand(80, 220));

    // 設定線，兩點一線
    imageline($image, rand(1, 149), rand(1, 29), rand(1, 149), rand(1, 29), $linecolor);
}

// 設定頭部，image/png
header('Content-Type: image/png');

// 建立 PNG 圖形
imagepng($image);

// 結束圖形函數
imagedestroy($image);
?>
