<?php
session_start();
include 'db.php';

$_SESSION['meal_deliver'] = 0;
// 获取POST请求中的选定縣市和區域
$selectedCounty = $_POST['selectedCounty'];
$selectedDistrict = $_POST['selectedDistrict'];

// 执行数据库查询（假设您有名为restaurants的表）
$sql = "SELECT * FROM restaurant WHERE restaurant_city = '$selectedCounty' AND  restaurant_area = '$selectedDistrict'";
$result = $link->query($sql);

// 处理查询结果
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // 输出每个餐廳的信息，您可以根据需要进行调整
        // echo "Restaurant Name: " . $row["restaurant_name"] . "<br>";
        $_SESSION['restaurant_name'] = $row["restaurant_name"];
        // var_dump($_SESSION);
        echo $row["restaurant_name"] . "：" . $row["restaurant_city"] . $row["restaurant_area"] . $row["restaurant_address"] . "<br>";
    }
}

$link->close();
?>
