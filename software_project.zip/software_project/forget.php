<?php
session_start();
require_once('db.php');
?>

<?php
  ini_set('display_errors', '1');

  if (isset($_POST["sendBt"])) {
    $memberAccount = $_POST['user_account'];
    $memberCaptcha= $_POST['authcode'];

    $sqlUser = "SELECT * FROM `user_info` WHERE `email` = '$memberAccount' OR `phone` = '$memberAccount'";
    $resultUser = mysqli_query($link, $sqlUser);
    $contentUser = @$resultUser->fetch_assoc();
    $thePhone = $contentUser['phone'];
    $rowCount = mysqli_num_rows($resultUser);
    if ($rowCount == 0) {
        $alert = "此帳號不存在";
        echo "<script type='text/javascript'>alert('$alert');</script>";
    } else if (isset($_REQUEST['authcode']) && $memberCaptcha != $_SESSION['authcode']){
        $alert = "驗證碼錯誤";
        echo "<script type='text/javascript'>alert('$alert');</script>";
    } else {
        $_SESSION['phone'] = $thePhone;
        header("Location:reset_num.php");
        exit;
    }
    mysqli_free_result($resultUser);
}
  mysqli_close($link);
?>

<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="Style_test.css">
  <title>肯德基登入系統</title>
  <script>
    function redirectToMenu(menuType) {
      const menuHtmlFiles = {
        '個人餐': 'personal_meal.php',
        '多人餐': 'family_meal.php',
        '早餐': 'breakfast.php',
        '單點': 'single_item.php',
      };
      const menuHtmlFile = menuHtmlFiles[menuType];
      if (menuHtmlFile) {
        window.location.href = menuHtmlFile;
      }
    }

    document.addEventListener("DOMContentLoaded", function () {
      document.getElementById("currentPageLabel").innerText = "忘記密碼";

      if (window.location.href.indexOf('your_login_link_here') !== -1) {
        document.getElementById("currentPageLabel").innerText = "會員登入";
        document.getElementById("currentPageLabel").classList.add("current-page-login-color");
      } else if (window.location.href.indexOf('your_forgot_password_link_here') !== -1) {
        document.getElementById("currentPageLabel").innerText = "忘記密碼";
        document.getElementById("currentPageLabel").classList.add("current-page-forgot-password-color");
      }
    }); 

  </script>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    
  <div class="menu-buttons">
    <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
    <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
    <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
    <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
  </div>
  
  <div class="container">
    <div class="login-form">
      <h1>忘記密碼</h1>
      <form autocomplete="off" action="forget.php" method="post">
        <input type="text" id="Email" maxlength="60" name="user_account" placeholder="請輸入會員帳號(email)或手機號碼" autocomplete="off">
        <div class="memberInputbox">
            <div class="input-wrapper">
                <input type="text" id="txtCaptcha" name="authcode" placeholder="驗證碼" required="1" maxlength="4">
            </div>
            <div class="verification_code">
                <p>
                  <img id="captcha_img" border='1' src='./captcha.php?r=echo rand(); ?>' style="width:150px; height:40px" />
                </p>
                <button class="btn white" type="button" onclick="document.getElementById('captcha_img').src='./captcha.php?r='+Math.random()">
                    <span>刷新驗證碼</span>
                </button>
            </div>
        </div>
        <button type="submit" class="btn block" id="btnsend" name="sendBt"><span>確認送出</span></button>
      </form>
    </div>
  </div>
  <div class="center-buttons-and-current-page">
    <button type="button" class="action-button" onclick="location.href='login.php'">
        會員登入
    </button>
    <button type="button" class="action-button" onclick="location.href='forget.php'">  
        <div class="current-page">
        <span id="currentPageLabel">忘記密碼</span>
    </div></button>
    <button type="button" class="action-button" onclick="location.href='sign_up.php'">
        加入會員
    </button>
  </div>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("currentPageLabel").innerText = "忘記密碼";

    if (window.location.href.indexOf('login.php') !== -1) {
        document.getElementById("currentPageLabel").innerText = "會員登入";
        document.getElementById("currentPageLabel").classList.add("current-page-login-color");
      } else if (window.location.href.indexOf('forget.php') !== -1) {
        document.getElementById("currentPageLabel").innerText = "忘記密碼";
        document.getElementById("currentPageLabel").classList.add("current-page-forgot-password-color");
      } else if (window.location.href.indexOf('sign_up.php') !== -1) {
        document.getElementById("currentPageLabel").innerText = "加入會員";
        document.getElementById("currentPageLabel").classList.add("current-page-add-member-color");
      }   
    });   
</script>

</body>
</html>
