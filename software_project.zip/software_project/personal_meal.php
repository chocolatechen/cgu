<!DOCTYPE html>
<html lang="UTF-8">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="order.css">
  <title>肯德基登入系統</title>
  <script>
    function redirectToMenu(menuType) {
        const menuHtmlFiles = {
          '個人餐': 'personal_meal.php',
          '多人餐': 'family_meal.php',
          '早餐': 'breakfast.php',
          '單點': 'single_item.php',
        };
        const menuHtmlFile = menuHtmlFiles[menuType];
        if (menuHtmlFile) {
          window.location.href = menuHtmlFile;
        }
      }
      
      document.addEventListener("DOMContentLoaded", function () {
      const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
      
      genderOptions.forEach(function (option) {
        option.addEventListener('change', function () {
          updateRadioStyles();
        });
      });
  
      updateRadioStyles();
    });
  
    function updateRadioStyles() {
      const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
  
      genderOptions.forEach(function (option) {
        const label = option.nextElementSibling;
  
        if (option.checked) {
          label.classList.add('checked');
        } else {
          label.classList.remove('checked');
        }
      });
    }
  </script>
</head>
<body>
  <div class="navbar">
    <div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
    </div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
      <script>
          function checkLogin() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (!response.loggedIn) {
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
      </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button.active-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
    </div>
    <div>
        <ul>
          <li><a href="#XL">XL 超豪肯!餐</a></li>
          <li><a href="#L">L 絕配餐</a></li>
          <li><a href="#M">M 經典餐</a></li>
          <li><a href="#S">S 雞勵餐</a></li>
          <li><a href="#salad">上校私廚沙拉</a></li>
        </ul>
    </div>
  </div>
  <script>
    function addToCart(button) {
        checkLogin();
        // 取得包含按鈕的 meals 元素
        var mealsElement = button.closest('.meals');
        
        // 從 meals 元素中取得餐點名稱
        var mealName = mealsElement.querySelector('h3').getAttribute('data-meal');

        // 使用 AJAX 向後端發送請求
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'addToCart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        // 將餐點名稱傳送到後端
        xhr.send('mealName=' + encodeURIComponent(mealName));

        // 等待後端回傳結果
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // 從後端回傳的資料中取得結果
                var result = xhr.responseText;
                if (result == "請先選擇餐廳、日期及時間") {
                  alert(result);
                  window.location.href = 'index.php';
                } else{
                  alert(result);
                  window.location.href = 'order_meal.php';
                }
                // 將結果顯示在前端
                // alert(result); // 這裡可以改成你希望的方式顯示回傳的文字
            }
        };
    }
  </script>
  <div class="content">
    <div id="XL" class="section-container">
      <div class = "meals-title">XL 超豪肯!餐</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-XL-20231127.jpg" alt="XL meals">
          <h3 data-meal="楓糖香蒜脆雞XL超豪肯餐">楓糖香蒜脆雞XL超豪肯餐</h4>
          <p>楓糖香蒜脆雞x2</p>
          <p>上校雞塊x4</p>
          <p>中薯x1</p>
          <p>原味蛋撻x1</p>
          <p>中可x1</p>
          <p class="meal-price">Price: $235</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-XL-20231019.jpg" alt="XL meals">
          <h3 data-meal="剝皮辣椒紙包雞XL套餐">剝皮辣椒紙包雞XL套餐</h3>
          <p>剝皮辣椒紙包雞x1</p>
          <p>雞汁風味飯x1</p>
          <p>上校雞塊x4</p>
          <p>原味蛋撻x1</p> 
          <p>百事可樂(中)x1</p>
          <p class="meal-price">Price: $239</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-XL%E9%A4%90-%E9%9D%92%E8%8A%B1%E6%A4%92%E9%BA%BB%E9%9B%9E20221215.jpg" alt="XL meals">
          <h3 data-meal="青花椒香麻脆雞XL套餐">青花椒香麻脆雞XL套餐</h3>
          <p>青花椒香麻脆雞x2</p>
          <p>上校雞塊x4</p>
          <p>香酥脆薯(中)x1</p>
          <p>原味蛋撻x1</p> 
          <p>百事可樂(中)x1</p>
          <p class="meal-price">Price: $235</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E5%8D%A1%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A1XL%E9%A4%9020220518.jpg" alt="XL meals">
          <h3 data-meal="青花椒香麻咔啦雞腿堡XL套餐">青花椒香麻咔啦雞腿堡XL套餐</h3>
          <p>青花椒香麻咔啦雞腿堡x1</p>
          <p>咔啦脆雞x1</p>
          <p>原味蛋撻x1</p>
          <p>香酥脆薯(中)x1</p> 
          <p>百事可樂(中)x1</p>
          <p class="meal-price">Price: $220</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E7%86%94%E5%B2%A9%E9%9B%9E%E8%85%BF%E5%A0%A1XL%E9%A4%9020220518.jpg" alt="XL meals">
          <h3 data-meal="花生熔岩咔啦雞腿堡XL套餐">花生熔岩咔啦雞腿堡XL套餐</h3>
          <p>花生熔岩咔啦雞腿堡(辣)X1</p>
          <p>咔啦脆雞(辣)X1</p>
          <p>香酥脆薯(中)X1</p>
          <p>原味蛋撻X1</p> 
          <p>百事可樂(中)x1</p>
          <p class="meal-price">Price: $235</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
    <div id="L" class="section-container">
      <div class = "meals-title">L 絕配餐</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-L-20231201.jpg" alt="L meals">
          <h3 data-meal="楓糖香蒜脆雞L絕配餐">楓糖香蒜脆雞L絕配餐</h3>
          <p>楓糖香蒜脆雞x2</p>
          <p>小薯x1</p>
          <p>中可x1</p>
          <p>原味蛋撻x1</p> 
          <p class="meal-price">Price: $195</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-L-20231019.jpg" alt="L meals">
          <h3 data-meal="剝皮辣椒紙包雞L絕配餐">剝皮辣椒紙包雞L絕配餐</h3>
          <p>剝皮辣椒紙包雞x1</p>
          <p>雞汁風味飯x1</p>
          <p>原味蛋撻x1</p>
          <p>百事可樂(中)x1</p> 
          <p class="meal-price">Price: $205</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-L%E9%A4%90-%E9%9D%92%E8%8A%B1%E6%A4%92%E9%BA%BB%E9%9B%9E20221214.jpg" alt="L meals">
          <h3 data-meal="青花椒香麻脆雞絕配餐">青花椒香麻脆雞絕配餐</h3>
          <p>青花椒香麻脆雞x2</p>
          <p>香酥脆薯(小)x1</p>
          <p>原味蛋撻x1</p>
          <p>百事可樂(中)x1</p>
          <p class="meal-price">Price: $195</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-L%E9%A4%90-%E9%9D%92%E8%8A%B1%E6%A4%92%E5%92%94%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A120221214.jpg" alt="L meals">
          <h3 data-meal="青花椒咔啦雞腿堡絕配餐">青花椒咔啦雞腿堡絕配餐</h3>
          <p>青花椒咔啦雞腿堡x1</p>
          <p>香酥脆薯(小)x1</p>
          <p>百事可樂(中)x1</p>
          <p>原味蛋撻x1</p> 
          <p class="meal-price">Price: $170</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-L%E9%A4%90-%E5%92%94%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A120221214.jpg" alt="L meals">
          <h3 data-meal="咔啦雞腿堡絕配餐">咔啦雞腿堡絕配餐</h3>
          <p>咔啦雞腿堡x1</p>
          <p>香酥脆薯(小)x1</p>
          <p>百事可樂(中)x1</p>
          <p>原味蛋撻x1</p> 
          <p class="meal-price">Price: $160</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
    <div id="M" class="section-container">
      <div class = "meals-title">M 經典餐</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E6%A5%93%E7%B3%96%E9%86%AC%E8%84%86%E9%9B%9E-M-20231127.jpg" alt="M meals">
          <h3 data-meal="楓糖香蒜脆雞M經典餐">楓糖香蒜脆雞M經典餐</h3>
          <p>楓糖香蒜脆雞x2</p>
          <p>香酥脆薯(中)x1</p>
          <p>百事可樂(中)x1</p> 
          <p class="meal-price">Price: $181</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%89%9D%E7%9A%AE%E8%BE%A3%E6%A4%92%E7%B4%99%E5%8C%85%E9%9B%9E-M-20231019.jpg" alt="M meals">
          <h3 data-meal="剝皮辣椒紙包雞M經典餐">剝皮辣椒紙包雞M經典餐</h3>
          <p>剝皮辣椒紙包雞x1</p>
          <p>雞汁風味飯x1</p>
          <p>百事可樂(中)x1</p> 
          <p class="meal-price">Price: $185</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E9%A6%99%E9%BA%BB%E8%84%86%E9%9B%9E%E5%80%8B%E4%BA%BA%E9%A4%9020220901.jpg" alt="M meals">
          <h3 data-meal="青花椒香麻脆雞經典餐">青花椒香麻脆雞經典餐</h3>
          <p>青花椒香麻脆雞(辣)*2</p>
          <p>中薯*1</p>
          <p>中可*1</p>
          <p class="meal-price">Price: $189</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E9%9D%92%E8%8A%B1%E6%A4%92%E5%8D%A1%E5%95%A6%E9%9B%9E%E8%85%BF%E5%A0%A1%E9%A4%9020220518.jpg" alt="M meals">
          <h3 data-meal="青花椒香麻咔啦雞腿堡經典餐">青花椒香麻咔啦雞腿堡經典餐</h3>
          <p>青花椒香麻咔啦雞腿堡x1</p>
          <p>香酥脆薯(中)x1</p>
          <p>百事可樂(中)x1</p> 
          <p class="meal-price">Price: $189</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E7%BE%8E%E5%BC%8F%E7%85%99%E7%87%BB%E5%92%94%E8%84%86%E9%9B%9E%E5%A0%A1-%E7%B6%93%E5%85%B8%E9%A4%9020230208.jpg" alt="M meals">
          <h3 data-meal="美式煙燻咔脆雞堡經典餐">美式煙燻咔脆雞堡經典餐</h3>
          <p>美式煙燻咔脆雞堡x1</p>
          <p>香酥脆薯(中)x1</p>
          <p>百事可樂(中)x1</p>
          <p class="meal-price">Price: $189</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
    <div id="S" class="section-container">
      <div class = "meals-title">S 雞勵餐</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E7%BE%8E%E5%BC%8F%E7%85%99%E7%87%BB%E5%92%94%E7%BE%8E%E5%BC%8F%E7%85%99%E7%87%BB%E5%92%94%E8%84%86%E9%9B%9E%E5%A0%A1-%E9%9B%9E%E5%8B%B5%E9%A4%9020230208.jpg" alt="S meals">
          <h3 data-meal="美式煙燻咔脆雞堡雞勵餐">美式煙燻咔脆雞堡雞勵餐</h3>
          <p>美式煙燻咔脆雞堡*1</p>
          <p>小可x1</p> 
          <p class="meal-price">Price: $109</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E5%92%94%E5%95%A6%E9%85%A5%E8%84%86%E9%A4%9020221214.jpg" alt="S meals">
          <h3 data-meal="咔啦酥脆雞勵餐">咔啦酥脆雞勵餐</h3>
          <p>咔啦脆雞x1</p>
          <p>上校雞塊x2</p>
          <p>百事可樂(小)x1</p>
          <p class="meal-price">Price: $109</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E5%8E%9F%E5%91%B3%E8%B5%B7%E5%8F%B8%E7%87%BB%E9%9B%9E%E6%8D%B2%E9%9B%9E%E5%8B%B5%E9%A4%9020221215.jpg" alt="S meals">
          <h3 data-meal="8塊上校雞塊雞勵餐">8塊上校雞塊雞勵餐</h3>
          <p>上校雞塊x8</p>
          <p>百事可樂(小)x1</p> 
          <p class="meal-price">Price: $99</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E8%8A%B1%E7%94%9F%E8%B5%B7%E5%8F%B8%E9%9B%9E%E6%9F%B3%E6%8D%B2%E9%9B%9E%E5%8B%B5%E9%A4%9020221215.jpg" alt="S meals">
          <h3 data-meal="原味起司燻雞捲雞勵餐">原味起司燻雞捲雞勵餐</h3>
          <p>原味起司燻雞捲x1</p>
          <p>百事可樂(小)x1</p> 
          <p class="meal-price">Price: $99</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/OLO%E9%A4%90%E5%9C%96-%E8%8A%B1%E7%94%9F%E8%B5%B7%E5%8F%B8%E9%9B%9E%E6%9F%B3%E6%8D%B2%E9%9B%9E%E5%8B%B5%E9%A4%9020221215.jpg" alt="S meals">
          <h3 data-meal="花生起司雞柳捲雞勵餐">花生起司雞柳捲雞勵餐</h3>
          <p>花生起司雞柳捲x1</p>
          <p>百事可樂(小)x1</p> 
          <p class="meal-price">Price: $99</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
    <div id="salad" class="section-container">
      <div class = "meals-title">上校私廚沙拉</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E7%83%A4%E9%9B%9E%E6%BA%AB%E6%B2%99%E6%8B%89%E5%A5%97%E9%A4%90(%E4%B8%8D%E9%81%A9%E7%94%A8%E5%A4%96%E9%80%81)-210927.jpg" alt="salad meals">
          <h3 data-meal="上校私廚烤雞腿溫沙拉套餐">上校私廚烤雞腿溫沙拉套餐</h3>
          <p>上校私廚烤雞腿溫沙拉X1</p>
          <p>玉米濃湯(小)X1</p>
          <p class="meal-price">Price: $178</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%87%B1%E8%96%A9%E7%83%A4%E5%9C%B0%E7%93%9C%E6%B2%99%E6%8B%89%E5%A5%97%E9%A4%9020220519.jpg" alt="salad meals">
          <h3 data-meal="凱薩烤地瓜沙拉套餐">凱薩烤地瓜沙拉套餐</h3>
          <p>凱薩烤地瓜沙拉x1</p>
          <p>經典玉米x1</p>
          <p>無糖茉莉綠茶(中)x1</p>
          <p class="meal-price">Price: $164</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E7%83%A4%E9%9B%9E%E6%BA%AB%E6%B2%99%E6%8B%89-%E5%96%AE%E9%BB%9E-211004.jpg" alt="salad meals">
          <h3 data-meal="上校私廚烤雞腿溫沙拉">上校私廚烤雞腿溫沙拉</h3>
          <p>上校私廚烤雞腿溫沙拉X1</p>
          <p class="meal-price">Price: $135</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%87%B1%E8%96%A9%E7%83%A4%E5%9C%B0%E7%93%9C%E6%B2%99%E6%8B%8920220518.jpg" alt="salad meals">
          <h3 data-meal="凱薩烤地瓜沙拉">凱薩烤地瓜沙拉</h3>
          <p>凱薩烤地瓜沙拉x1</p>
          <p class="meal-price">Price: $129</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
  </div>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const navbarLinks = document.querySelectorAll('.navbar a');
    
      window.addEventListener('scroll', function () {
        const scrollPosition = window.scrollY || document.documentElement.scrollTop;
    
        navbarLinks.forEach(function (link) {
          const targetId = link.getAttribute('href').substring(1);
          const targetElement = document.getElementById(targetId);
    
          if (targetElement) {
            const isInViewport = isElementInViewport(targetElement);
    
            if (isInViewport) {
              link.classList.add('active-link');
            } else {
              link.classList.remove('active-link');
            }
          }
        });
      });
    
      function isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    
        // Check if at least 50% of the element is visible
        return (
          rect.top >= 0 &&
          rect.left >= 0 &&
          rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
        );
      }
    });
    
  </script>
  <footer>
    &copy; 2023 Software Term Project
  </footer>
  
</body>
</html>