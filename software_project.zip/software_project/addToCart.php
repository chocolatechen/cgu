<?php
session_start();
require_once('db.php');

$mealName = $_POST['mealName'];
$_SESSION["mealName"] = $mealName;
// var_dump($_SESSION);

// 查詢 meal 表中是否存在相應的餐點
$sql = "SELECT * FROM `meals` WHERE `meal_name` = '$mealName'";
$result = mysqli_query($link, $sql);

if (!isset($_SESSION['restaurant_name']) && !isset($_SESSION['orderDate']) && !isset($_SESSION['orderTime'])) {
    $response = "請先選擇餐廳、日期及時間";
} else if ($result) {
    // 如果餐點存在，可以進行相應的處理
    if (mysqli_num_rows($result) > 0) {
        // 餐點存在
        $response = "餐點：$mealName";
    } else {
        // 餐點不存在
        $response = "找不到相應的餐點：$mealName";
    }
} else {
    // 查詢失敗的處理
    $response = "查詢失敗";
}

// 回傳結果給前端
echo $response;
?>
