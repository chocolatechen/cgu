<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["mobile"])) {
  $mobile = mysqli_real_escape_string($link, $_POST["mobile"]);

  $sql = "SELECT * FROM `user_info` WHERE `phone` = '$mobile'";
  $result = mysqli_query($link, $sql);
  $rowCount = mysqli_num_rows($result);

  if ($rowCount > 0) {
    echo "duplicate";
  } else {
    echo "unique";
  }

  mysqli_free_result($result);
}

mysqli_close($link);
?>
