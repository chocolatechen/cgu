<?php
session_start();
require_once('db.php');
?>

<?php
    ini_set('display_errors', '1');

    if (isset($_SESSION['member_id']) && $_SESSION['member_id'] == true) {
        $theMemberid = $_SESSION['member_id'];
    }

    if (isset($_POST["pay"])) {
        $bag = $_POST["bag"];
        // $stmt = "INSERT INTO customer_order (shopping_bag) VALUES ('$bag')";
        // mysqli_query($link, $stmt);
    }

    $sqlOrder = "SELECT `meal_name` , `num_meal`, `total_price` FROM `customer_order` WHERE `member_id` = '$theMemberid' and `is_pay` = 0";
    $result = mysqli_query($link, $sqlOrder);
    $countmeal = 0;
    $totalPrice = 0;
    $allOutput = '';
    while ($contentOrder = @$result->fetch_assoc()) {
        $main_meal = $contentOrder["meal_name"];
        $number = $contentOrder["num_meal"];
        $price = $contentOrder["total_price"];
        $totalPrice += $contentOrder["total_price"];
        $countmeal += 1;

        if ($main_meal) {
            $sqlDetail = "SELECT `detail` FROM `meals` WHERE `meal_name` = '$main_meal'";
            $detailResult = mysqli_query($link, $sqlDetail);
            $row = mysqli_fetch_assoc($detailResult);
            $detail = $row['detail'];
            
            $substr = explode(']', $detail);
            
            $count = count($substr);
            $output = '<div>';
            $output .= '<ul>';
            $output .= '<li>' . $main_meal . '<button class="change-meals-button" onclick="location.href=\'change_meals.php\'">修改</button>';
            $output .= '<button class="delete-button" onclick="openModal(\'meals1\')">X</button></li>';
            $output .= '</ul>'; 
            foreach ($substr as $index => $part) {
                $lastPart = ($index === $count - 1);
                $cut = $lastPart ? $part : substr($part, 0, -3);
                $output .= "<p>" . $cut . "</p>";
            }
            $output .= '<div class="price-container">' . '<div class="additional-text">' . $number . '份</div>';
            $output .= '<div class="price">$' . $price . '</div>';
            $output .= '</div>';
            $allOutput .= $output;
        }
    }
?>

<!DOCTYPE html>
<html lang="UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="cart.css">
    <title>肯德基登入系統</title>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    
    <div class="cart-container">
        <div class="header-text">
            <p>&nbsp&nbsp餐點內容</p>
        </div>
        <div class="cart-card">
            <ul>
                <?php echo $allOutput;?>
            </ul>           
        </div>
        <h5>若訂購餐點份數較多，建議加購購物袋。</h5>
        <div class="container">
            <div class="checkbox-container">
                <input type="checkbox" class="card-checkbox" id="checkbox1" onchange="toggleDropdown('dropdown1', 3)">
                <label name="bag" for="checkbox1" class="checkbox-text">購物袋</label>
                <div class="dropdown" id="dropdown1">
                    <select id="quantityDropdown" onchange="updateTotalAmount(1)">
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                    </select>
                </div>
            </div>
            <div class="total-amount" id="totalAmount">$0</div>
        </div>
        <script>
            var totalOrderPrice = <?php echo $totalPrice; ?>;

            function updateTotalAmount(pricePerBag) {
                var totalAmountElement = document.getElementById('totalAmount');
                var selectedValue = document.getElementById('quantityDropdown').value;
                var bagPrice = selectedValue * pricePerBag;
                var totalPrice = totalOrderPrice + bagPrice;

                // 更新袋子價格
                totalAmountElement.innerHTML = '$' + bagPrice;

                // 更新整體金額總計
                var totalContainerElement = document.querySelector('.total-container p');
                totalContainerElement.textContent = '$' + totalPrice;
            }

            function toggleDropdown(dropdownId, pricePerBag) {
                var dropdown = document.getElementById(dropdownId);
                var checkbox = document.getElementById('checkbox1');
                
                if (checkbox.checked) {
                    // 勾選購物袋，執行更新
                    updateTotalAmount(pricePerBag);
                } else {
                    // 取消勾選購物袋，價格為零
                    updateTotalAmount(0);
                }
                
                if (dropdown) {
                    dropdown.classList.toggle('active', checkbox.checked);
                }
            }
        </script>
    </div>
    <hr>
        <div class="total-container">
            <h2>金額總計</h2>
            <p>$<?php echo $totalPrice?></p>
        </div>
    <hr>
    <button type="submit" name="pay" class="check-button" onclick="redirectToMenu('結帳')">立即結帳</button>
    <div class="modal" id="warnmessage">
        <div class="modal-content">
          <p>Are you sure you want to delete this item?</p>
          <div class="modal-buttons">
            <button class="model-delete-button" onclick="deleteCartItem()">Confirm</button>
            <button class="model-delete-button" onclick="closeModal()">Cancel</button>
          </div>
        </div>
    </div>
    <script>
        var currentCardToDelete;

        function openModal(cardId) {
            currentCardToDelete = cardId; // 设置当前要删除的卡片标识
            var modal = document.getElementById("warnmessage");
            modal.style.display = "flex";
        }

        function closeModal() {
            var modal = document.getElementById("warnmessage");
            modal.style.display = "none";
        }

        function deleteCartItem() {
            var listItem = document.getElementById(currentCardToDelete);

            // 如果找到了要删除的元素，则删除
            if (listItem) {
                listItem.parentNode.removeChild(listItem);
            }

            // 关闭模态框
            closeModal();
        }
        
        function redirectToMenu(menuType) {
            const menuHtmlFiles = {
              '修改': 'change_meals.php',
              '結帳': 'paybill.php',
            };
            const menuHtmlFile = menuHtmlFiles[menuType];
            if (menuHtmlFile) {
              window.location.href = menuHtmlFile;
            }
          }
    </script>
    <footer>
        &copy; 2023 Software Term Project
    </footer>
</body>
</html>