<?php
session_start();
require_once('db.php');
?>

<?php 
    ini_set('display_errors', '1');

    if (isset($_SESSION['member_id']) && $_SESSION['member_id'] == true) {
      $theMemberid = $_SESSION['member_id'];
      $sql = "SELECT `user_name` FROM `user_info` WHERE `member_id` = '$theMemberid'";
      $result = mysqli_query($link, $sql);
      $contentUser = $result->fetch_assoc();
      $customer_name = $contentUser['user_name'];
    }
    if (isset($_SESSION['mea_deliver']) && $_SESSION['meal_deliver'] == true) {
        $theMealdeliver = (int)$_SESSION['meal_deliver']; 
    }
    if (isset($_SESSION['restaurant_name']) && $_SESSION['restaurant_name'] == true) {
        $restaurant_name = $_SESSION['restaurant_name'];
    }
    if (isset($_SESSION['mealName']) && $_SESSION['mealName'] == true) {
        $mealName = $_SESSION['mealName'];
    }
    if (isset($_SESSION['orderDate']) && $_SESSION['orderDate'] == true) {
        $orderDate = $_SESSION['orderDate'];
    }
    if (isset($_SESSION['orderTime']) && $_SESSION['orderTime'] == true) {
        $orderTime = $_SESSION['orderTime'];
    }
    // var_dump($_SESSION);
    if (isset($_POST["change"])) {
        $meal = $_POST["meal"];
    }

    $image = "";
    $allOutput = "";
    $output = "";
    $sql = "SELECT `detail`, `price`, `image` FROM `meals` WHERE `meal_name` = '$mealName'";
    $result = mysqli_query($link, $sql);
    $i = 0;
    while ($contentOrder = @$result->fetch_assoc()) {
        $price = $contentOrder["price"];
        $detail = $contentOrder["detail"];
        $mainImage = $contentOrder["image"];

        $substr = explode(']', $detail);        
        $count = count($substr);
        foreach ($substr as $index => $part) {
          $output .= '<div class="card">' . '<div class="card-image">';  
          $last = ($index === $count - 1);
          $cut = $last ? $part : substr($part, 0, -3);
          $chineseName = strstr($cut, '(', true);
          if ($chineseName) {
            // echo $chineseName;
            $sql2 = "SELECT `image` FROM `meals` WHERE '$chineseName' = `meal_name`";
            $result2 = mysqli_query($link, $sql2);
            $row = mysqli_fetch_assoc($result2);
            // $image = $row["image"];
          }

          if ($i == 0) {
            $output .= '<img class="image" src="' . $mainImage . '">'; 
            $output .= '</div>' . '<div class="card-content">' . '<h3>主餐</h3>' . '<p>' . $chineseName . '</p>' . '</div>' . '</div>';
            $i = 1;
          } else {
            $output .= '<img class="image" src="' . "https://kfcoosfs.kfcclub.com.tw/%E9%A6%99%E9%85%A5%E8%84%86%E8%96%AF(%E4%B8%AD)-210726.jpg" . '">';
            $output .= '</div>' . '<div class="card-content">' . '<h4>配餐</h4>' . '<p name="meal">' . $chineseName . '</p>' . '</div>' . '<div class="card-button">';
            $output .= '<a type="submit" name="change" class="change" href="change_meals.php">更換</a>' . '</div>' . '</div>';
          }
        }
        $allOutput .= $output;
      }

      $sqlOrder = "SELECT `meal_name`, `price`, `image` FROM `meals` WHERE `meal_name` = '$mealName'";
      $result = mysqli_query($link, $sqlOrder);

      $allOutput2 = '';
      while ($contentOrder = @$result->fetch_assoc()) {
          $main_meal = $contentOrder["meal_name"];
          $price = $contentOrder["price"];
          $image = $contentOrder["image"];

          if ($main_meal) {
              $sqlDetail = "SELECT `detail` FROM `meals` WHERE `meal_name` = '$main_meal'";
              $detailResult = mysqli_query($link, $sqlDetail);
              $row = mysqli_fetch_assoc($detailResult);
              $detail = $row['detail'];
              
              $substr = explode(']', $detail);
              
              $count = count($substr);
              $output2 = '<div class="image-container">' . '<img class="image" src="' . $image . '" alt="Image">';
              $output2 .= '<div class="image-description">' . '<h2>' . $main_meal . '</h2>';
              foreach ($substr as $index => $part) {
                  $lastPart = ($index === $count - 1);
                  $cut = $lastPart ? $part : substr($part, 0, -3);
                  $output2 .= "<h4>" . $cut . "</h4>";
              }
              $output2 .= '<hr style="color:darkgrey #001">' . '<div class="price-container">';
              $output2 .= '<h4>餐點小計:</h4>' . '<h3>$' . $price . '</h3>';
              $output2 .= '</div>' . '</div>' . '</div>';
              $allOutput2 .= $output2;
          }
      }
      if (isset($_POST["add"])) {
        // member_id, customer_name, meal_deliver這三個需要session
        // $num_meal = $_POST["num_meal"];
        $total_price = $price;
        $sql = "INSERT INTO `customer_order` (member_id, customer_name, restaurant_name, order_date, order_time, meal_name, num_meal, extra_order_name, meal_deliver, total_price, note, is_pay, shopping_bag)
                                      VALUES ('$theMemberid', '$customer_name', '$restaurant_name', '$orderDate', '$orderTime', '$mealName', 1, NULL, 0, '$total_price', NULL, 0, 0)";
        if (mysqli_query($link, $sql)) {
          echo "<script type='text/javascript'>alert('餐點已加入購物車'); window.location.href = 'index.php'</script>";
        }
      }
?>

<!DOCTYPE html>
<html lang="UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="shopping.css">
    <title>肯德基登入系統</title>
    <script>
    function redirectToMenu(menuType) {
      const menuHtmlFiles = {
        '個人餐': 'personal_meal.php',
        '多人餐': 'family_meal.php',
        '早餐': 'breakfast.php',
        '單點': 'single_item.php',
      };
      const menuHtmlFile = menuHtmlFiles[menuType];
      if (menuHtmlFile) {
        window.location.href = menuHtmlFile;
      }
    }
    

    document.addEventListener("DOMContentLoaded", function () {
    const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
    
    genderOptions.forEach(function (option) {
      option.addEventListener('change', function () {
        updateRadioStyles();
      });
    });

    updateRadioStyles();
  });

  function updateRadioStyles() {
    const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');

    genderOptions.forEach(function (option) {
      const label = option.nextElementSibling;

      if (option.checked) {
        label.classList.add('checked');
      } else {
        label.classList.remove('checked');
      }
    });
  }
    </script>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
    </div>
    <div class = "cart-container">
        <div class="card-container">
          <?php echo $allOutput?>
          <!-- <div class="card">
              <div class="card-image">
                  <img class="image" src="https://kfcoosfs.kfcclub.com.tw/M-%e6%a5%93%e7%b3%96%e9%86%ac%e8%84%86%e9%9b%9e20231127.png">
              </div>
              <div class="card-content">
                  <h3>主餐</h3>
                  <p>楓糖香蒜脆雞(辣)x2</p>
              </div>
          </div> -->
          <!-- <div class="card">
            <div class="card-image">
                <img class="image" src="https://kfcoosfs.kfcclub.com.tw/%e4%b8%8a%e6%a0%a1%e9%9b%9e%e5%a1%8a4%e5%a1%8a.png">
            </div>
            <div class="card-content">
                <h4>配餐</h4>
                <p name="meal">上校雞塊4塊x1</p>
            </div>
          </div> -->
          <!-- <div class="card">
            <div class="card-image">
                <img class="image" src="https://kfcoosfs.kfcclub.com.tw/M-%e9%a6%99%e9%85%a5%e8%84%86%e8%96%af(%e4%b8%ad)-210726.png">
            </div>
            <div class="card-content">
                <h4>配餐</h4>
                <p name="meal">香酥脆薯(中)x1</p>
            </div>
            <div class="card-button">
              <a type="submit" name="change" class="change" href="change_meals.html">更換</a>
            </div>
          </div> -->
          <!-- <div class="card">
            <div class="card-image">
                <img class="image" src="https://kfcoosfs.kfcclub.com.tw/%e5%8e%9f%e5%91%b3%e8%9b%8b%e6%92%bb.png">
            </div>
            <div class="card-content">
                <h4>配餐</h4>
                <p name="meal">原味蛋撻x1</p>
            </div>
            <div class="card-button">
              <a type="submit" class="change" name="change"  href="change_meals.html">更換</a>
            </div>
          </div> -->
          <!-- <div class="card">
            <div class="card-image">
                <img class="image" name="change" src="https://kfcoosfs.kfcclub.com.tw/M-%e5%8f%af%e6%a8%82%e4%b8%ad-210512.png">
            </div>
            <div class="card-content">
                <h4>飲料</h4>
                <p name="meal">百事可樂(中)x1</p>
            </div>
            <div class="card-button">
              <a type="submit" class="change" href="change_meals.html">更換</a>
            </div>
          </div> -->
          <form method="post">
          <div class="button-container">
            <button class="button" onclick="adjustNumber(-1)">-</button>
            <div name="num_meal" class="number-display" id="numberDisplay">1</div>
            <button class="button" onclick="adjustNumber(1)">+</button>
            <div class="price">餐點$<span name="price"><?php echo $price?></span></div>
          </div>
          <script>
            let currentNumber = 0;
        
            function adjustNumber(change) {
              currentNumber += change;
              if(currentNumber >= 0) {
                document.getElementById('numberDisplay').innerText = currentNumber;
              } else {
                currentNumber = 0;
              }
            }
          </script>
          <div class="check-button-container" onclick="addtocart()">
              <button name="add" type="submit" class="check-button">加入餐車</button>
          </div>
          </form>
          <div class="check-button-container" onclick="redirectToCart()">
              <button class="cancel-button">回到菜單</button>
          </div>
        </div>
        <script>
          function redirectToCart() {
            window.location.href = 'index.php';
          }

          function addtocart() {
            console.log("Add something to cart");
          }
        </script>
        <?php echo $allOutput2?>
        <!-- <div class="image-container">
            <img class="image" src="https://kfcoosfs.kfcclub.com.tw/%e6%a5%93%e7%b3%96%e9%86%ac%e8%84%86%e9%9b%9e-XL-20231127-pc.jpg" alt="Image">
            <div class="image-description">
              <h2>楓糖香蒜脆雞XL超豪肯餐</h2>
              <h4>楓糖香蒜脆雞(辣)x2</h4>
              <h4>上校雞塊4塊x1</h4>
              <h4>香酥脆薯(中)x1</h4>
              <h4>原味蛋撻x1</h4>
              <h4>百事可樂(中)x1</h4>
              <hr style="color:darkgrey #001">
              <div class="price-container">
                <h4>餐點小計:</h4>
                <h3>$235</h3>
              </div>
            </div>
        </div> -->
    </div>


  <footer>
    &copy; 2023 Software Term Project
  </footer>
</body>
</html>