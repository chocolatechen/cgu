<!DOCTYPE html>
<html lang="UTF-8">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="order.css">
  <title>肯德基登入系統</title>
  <script>
    function redirectToMenu(menuType) {
        const menuHtmlFiles = {
          '個人餐': 'personal_meal.php',
          '多人餐': 'family_meal.php',
          '早餐': 'breakfast.php',
          '單點': 'single_item.php',
        };
        const menuHtmlFile = menuHtmlFiles[menuType];
        if (menuHtmlFile) {
          window.location.href = menuHtmlFile;
        }
      }
      
      document.addEventListener("DOMContentLoaded", function () {
      const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
      
      genderOptions.forEach(function (option) {
        option.addEventListener('change', function () {
          updateRadioStyles();
        });
      });
  
      updateRadioStyles();
    });
  
    function updateRadioStyles() {
      const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
  
      genderOptions.forEach(function (option) {
        const label = option.nextElementSibling;
  
        if (option.checked) {
          label.classList.add('checked');
        } else {
          label.classList.remove('checked');
        }
      });
    }
  </script>
</head>
<body>
  <div class="navbar">
    <div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
  </div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
      <script>
          function checkLogin() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (!response.loggedIn) {
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
      </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button.active-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
    </div>
    <div>
        <ul>
          <li><a href="#package">早餐套餐</a></li>
          <li><a href="#single">早餐單點</a></li>
        </ul>
    </div>
  </div>
  <script>
    function addToCart(button) {
        checkLogin();
        // 取得包含按鈕的 meals 元素
        var mealsElement = button.closest('.meals');
        
        // 從 meals 元素中取得餐點名稱
        var mealName = mealsElement.querySelector('h3').getAttribute('data-meal');

        // 使用 AJAX 向後端發送請求
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'addToCart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        // 將餐點名稱傳送到後端
        xhr.send('mealName=' + encodeURIComponent(mealName));

        // 等待後端回傳結果
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // 從後端回傳的資料中取得結果
                var result = xhr.responseText;
                if (result == "請先選擇餐廳、日期及時間") {
                  alert(result);
                  window.location.href = 'index.php';
                } else{
                  alert(result);
                  window.location.href = 'order_meal.php';
                }
                // 將結果顯示在前端
                // alert(result); // 這裡可以改成你希望的方式顯示回傳的文字
            }
        };
    }
  </script>
  <div class="content">
    <div id="package" class="section-container">
      <div class = "meals-title">早餐套餐</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1-%E5%A5%97%E9%A4%9020221115.jpg">
          <h3 data-meal="花生吮指嫩雞蛋堡套餐">花生吮指嫩雞蛋堡套餐</h4>
          <p>花生吮指嫩雞蛋堡x1</p>
          <p>經典熱奶茶(小)x1</p>
          <p class="meal-price">Price: $79</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%82%89%E9%AC%86%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1-%E5%A5%97%E9%A4%9020221115.jpg">
          <h3 data-meal="花生肉鬆嫩雞蛋堡套餐">花生肉鬆嫩雞蛋堡套餐</h4>
          <p>花生肉鬆嫩雞蛋堡x1</p>
          <p>經典熱奶茶(小)x1</p>
          <p class="meal-price">Price: $79</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1%E5%A5%97%E9%A4%900724.jpg">
          <h3>吮指嫩雞蛋堡套餐</h4>
          <p>吮指嫩雞蛋堡x1</p>
          <p>經典熱奶茶(小)x1</p>
          <p class="meal-price">Price: $69</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%B5%B7%E5%8F%B8%E8%9B%8B%E5%A0%A1-%E5%A5%97%E9%A4%9020221115.jpg">
          <h3 data-meal="花生起司蛋堡套餐">花生起司蛋堡套餐</h4>
          <p>花生起司蛋堡x1</p>
          <p>經典熱奶茶(小)x1</p>
          <p class="meal-price">Price: $49</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E6%8D%B2%E9%A4%85-%E5%A5%97%E9%A4%9020221115.jpg">
          <h3 data-meal="吮指嫩雞蛋捲餅套餐">吮指嫩雞蛋捲餅套餐</h4>
          <p>吮指嫩雞蛋捲餅x1</p>
          <p>經典熱奶茶(小)x1</p>
          <p class="meal-price">Price: $85</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
    <div id="single" class="section-container">
      <div class = "meals-title">早餐單點</div>
      <div class="meals-container">
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A120221115.jpg">
          <h3 data-meal="花生吮指嫩雞蛋堡">花生吮指嫩雞蛋堡</h3>
          <p>花生吮指嫩雞蛋堡x1</p>
          <p class="meal-price">Price: $60</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%82%89%E9%AC%86%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A120221115.jpg">
          <h3 data-meal="花生肉鬆嫩雞蛋堡">花生肉鬆嫩雞蛋堡</h3>
          <p>花生肉鬆嫩雞蛋堡x1</p>
          <p class="meal-price">Price: $60</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E5%A0%A1.jpg">
          <h3 data-meal="吮指嫩雞蛋堡">吮指嫩雞蛋堡</h3>
          <p>吮指嫩雞蛋堡x1</p>
          <p class="meal-price">Price: $50</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E8%8A%B1%E7%94%9F%E8%B5%B7%E5%8F%B8%E8%9B%8B%E5%A0%A120221115.jpg">
          <h3 data-meal="花生起司蛋堡">花生起司蛋堡</h3>
          <p>花生起司蛋堡x1</p>
          <p class="meal-price">Price: $35</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
        <div class="meals">
          <img src="https://kfcoosfs.kfcclub.com.tw/%E5%90%AE%E6%8C%87%E5%AB%A9%E9%9B%9E%E8%9B%8B%E6%8D%B2%E9%A4%8520221115.jpg">
          <h3 data-meal="吮指嫩雞蛋捲餅">吮指嫩雞蛋捲餅</h3>
          <p>吮指嫩雞蛋捲餅x1</p>
          <p class="meal-price">Price: $66</p>
          <button class="meals-button" onclick="addToCart(this)">訂購</button>
        </div>
      </div>
    </div>
  </div>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const navbarLinks = document.querySelectorAll('.navbar a');
    
      window.addEventListener('scroll', function () {
        const scrollPosition = window.scrollY || document.documentElement.scrollTop;
    
        navbarLinks.forEach(function (link) {
          const targetId = link.getAttribute('href').substring(1);
          const targetElement = document.getElementById(targetId);
    
          if (targetElement) {
            const isInViewport = isElementInViewport(targetElement);
    
            if (isInViewport) {
              link.classList.add('active-link');
            } else {
              link.classList.remove('active-link');
            }
          }
        });
      });
    
      function isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    
        // Check if at least 50% of the element is visible
        return (
          rect.top >= 0 &&
          rect.left >= 0 &&
          rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
        );
      }
    });
    
  </script>
  <footer>
    &copy; 2023 Software Term Project
  </footer>
  
</body>
</html>