<?php
session_start();
require_once('db.php');
?>

<?php
    ini_set('display_errors', '1');

    // if (isset($_POST["check"])) {
    //     redirectToOrigin();
    // }
    

    $sql = "SELECT `can_change_meal_name`, `price_diff` FROM `customize_meals` WHERE `customize_meal_name` = '百事可樂(中)'";
    $result = mysqli_query($link, $sql);
    $output = "";
    $allOutput = "";
    while ($changeOther = @$result->fetch_assoc()) {
        $changeMeal = $changeOther["can_change_meal_name"];
        $diffPrice = $changeOther["price_diff"];

        if ($changeMeal) {
            $sql2 = "SELECT `image` FROM `meals` WHERE '$changeMeal' = `meal_name`";
            $result2 = mysqli_query($link, $sql2);
            $row = mysqli_fetch_assoc($result2);
            $image = $row["image"];
        }

        $output .= '<div class="card">' . '<div class="card-image">';
        $output .= '<img class="image" src="' . $image . '">';
        $output .= '</div>' . '<div class="card-content">' . '<h3>' . $changeMeal . '</h3>' . '<h3>+' . $diffPrice . '</h3>';
        $output .= '<div class="button-container">' . '<button class="button" onclick="adjustNumber(-1, "numberDisplay1")">-</button>';
        $output .= '<div class="number-display" id="numberDisplay1">0</div>' . '<button class="button" onclick="adjustNumber(1, "numberDisplay1")">+</button>';
        $output .= '</div>' . '</div>' . '</div>';
    }
    $allOutput .= $output;
?>

<!DOCTYPE html>
<html lang="UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="meals_detail.css">
    <title>肯德基登入系統</title>
    <script>
    function redirectToMenu(menuType) {
      const menuHtmlFiles = {
        '個人餐': 'personal_meal.php',
        '多人餐': 'family_meal.php',
        '早餐': 'breakfast.php',
        '單點': 'single_item.php',
      };
      const menuHtmlFile = menuHtmlFiles[menuType];
      if (menuHtmlFile) {
        window.location.href = menuHtmlFile;
      }
    }
    

    document.addEventListener("DOMContentLoaded", function () {
    const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
    
    genderOptions.forEach(function (option) {
      option.addEventListener('change', function () {
        updateRadioStyles();
      });
    });

    updateRadioStyles();
  });

  function updateRadioStyles() {
    const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');

    genderOptions.forEach(function (option) {
      const label = option.nextElementSibling;

      if (option.checked) {
        label.classList.add('checked');
      } else {
        label.classList.remove('checked');
      }
    });
  }
    </script>
</head>
<body>
<div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
</div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
    <div class="menu-buttons">
        <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
        <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
    </div>
    <div class = "cart-container">
        <div class="card-container">
            <h2>&nbsp&nbsp飲料</h2>
            <span>&nbsp&nbsp共可選 1 杯</span>
            <?php echo $allOutput?>
            <!-- <div class="card">
                <div class="card-image">
                    <img class="image" src="https://kfcoosfs.kfcclub.com.tw/M-%E5%8F%AF%E6%A8%82%E4%B8%AD-210512.png">
                </div>
                <div class="card-content">
                    <h3>百事可樂(中)</h3>
                    <h3>+10</h3>
                    <div class="button-container">
                        <button class="button" onclick="adjustNumber(-1, 'numberDisplay1')">-</button>
                        <div class="number-display" id="numberDisplay1">0</div>
                        <button class="button" onclick="adjustNumber(1, 'numberDisplay1')">+</button>
                    </div>
                </div>
            </div> -->
            <!-- <div class="card">
                <div class="card-image">
                    <img class="image" src="https://kfcoosfs.kfcclub.com.tw/M-%E4%B8%83%E5%96%9C(%E4%B8%AD)-210608.png">
                </div>
                <div class="card-content">
                    <h3>七喜(中)</h3>
                    <div class="button-container">
                        <button class="button" onclick="adjustNumber(-1, 'numberDisplay2')">-</button>
                        <div class="number-display" id="numberDisplay2">0</div>
                        <button class="button" onclick="adjustNumber(1, 'numberDisplay2')">+</button>
                    </div>
                </div>
            </div> -->
            <!-- <div class="card">
                <div class="card-image">
                    <img class="image" src="https://kfcoosfs.kfcclub.com.tw/M-%E7%B4%85%E8%8C%B620230425.png">
                </div>
                <div class="card-content">
                    <h3>立頓檸檬風味紅茶(中)</h3>
                    <div class="button-container">
                        <button class="button" onclick="adjustNumber(-1, 'numberDisplay3')">-</button>
                        <div class="number-display" id="numberDisplay3">0</div>
                        <button class="button" onclick="adjustNumber(1, 'numberDisplay3')">+</button>
                    </div>
                </div>
            </div> -->
            <!-- <div class="card">
                <div class="card-image">
                    <img class="image" src="https://kfcoosfs.kfcclub.com.tw/%E5%86%B0%E7%84%A1%E7%B3%96%E8%8C%89%E8%8E%89%E7%B6%A0%E8%8C%B6(%E5%B0%8F).png">
                </div>
                <div class="card-content">
                    <h3>冰無糖綠茶(中)</h3>
                    <div class="button-container">
                        <button class="button" onclick="adjustNumber(-1, 'numberDisplay4')">-</button>
                        <div class="number-display" id="numberDisplay4">0</div>
                        <button class="button" onclick="adjustNumber(1, 'numberDisplay4')">+</button>
                    </div>
                </div>
            </div> -->
            <!-- <div class="card">
                <div class="card-image">
                    <img class="image" src="https://kfcoosfs.kfcclub.com.tw/%E7%86%B1%E7%B4%85%E8%8C%B6.png">
                </div>
                <div class="card-content">
                    <h3>熱紅茶</h3>
                    <div class="button-container">
                        <button class="button" onclick="adjustNumber(-1, 'numberDisplay5')">-</button>
                        <div class="number-display" id="numberDisplay5">0</div>
                        <button class="button" onclick="adjustNumber(1, 'numberDisplay5')">+</button>
                    </div>
                </div>
            </div> -->
            <hr>
            <div class="check-button-container">
                <button class="check-button" onclick="redirectToOrigin();">確認餐點</button>
            </div>
            <div class="check-button-container" onclick="redirectToOrigin();">
                <button class="cancel-button">取消</button>
            </div>
          <script>
            //can limit the total number of items
            let totalSum = 0;

            function adjustNumber(amount, displayId, limit) {
                let numberDisplay = document.getElementById(displayId);
                let currentNumber = parseInt(numberDisplay.innerText);
                let newNumber = currentNumber + amount;
                //totalSum + amount <= limit
                if (totalSum + amount <= 1 && newNumber >= 0) {
                    numberDisplay.innerText = newNumber;
                    totalSum += amount;
                }
            }

            function redirectToOrigin() {
                if (typeof window.history !== 'undefined') {
                    window.history.back();
                } else {
                    // 如果不支援 history API，可以將其重定向到首頁或其他預設頁面
                    window.location.href = 'index.php';
                }
            }

            // function redirectToCart() {
            //     // 使用 window.location.href 跳转到 cart.html 页面
            //     window.location.href = 'cart.php';
            // }
          </script>
        </div>
        <div class="image-container">
            <img class="image" src="https://kfcoosfs.kfcclub.com.tw/%e6%a5%93%e7%b3%96%e9%86%ac%e8%84%86%e9%9b%9e-XL-20231127-pc.jpg" alt="Image">
        </div>
    </div>


  <footer>
    &copy; 2023 Software Term Project
  </footer>
</body>
</html>