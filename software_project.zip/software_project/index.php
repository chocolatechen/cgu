<?php
  session_start();
  require_once('db.php');
?>

<?php
  
?>

<!DOCTYPE html>
<html lang="UTF-8">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="homepage.css">
  <title>肯德基登入系統</title>
  <script>
    function redirectToMenu(menuType) {
      const menuHtmlFiles = {
        '個人餐': 'personal_meal.php',
        '多人餐': 'family_meal.php',
        '早餐': 'breakfast.php',
        '單點': 'single_item.php',
      };
      const menuHtmlFile = menuHtmlFiles[menuType];
      if (menuHtmlFile) {
        window.location.href = menuHtmlFile;
      }
    }
    

    document.addEventListener("DOMContentLoaded", function () {
    const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');
    
    genderOptions.forEach(function (option) {
      option.addEventListener('change', function () {
        updateRadioStyles();
      });
    });

    updateRadioStyles();
  });

  function updateRadioStyles() {
    const genderOptions = document.querySelectorAll('.gender-options input[type="radio"]');

    genderOptions.forEach(function (option) {
      const label = option.nextElementSibling;

      if (option.checked) {
        label.classList.add('checked');
      } else {
        label.classList.remove('checked');
      }
    });
  }
  </script>
</head>
<body>
  <div class="header">
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="location.href='index.php'">
              <img src="./images/KFC_image.jpg" class="logo">
          </button>
      </div>
  
      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_1()">
              <img src="./images/head.jpg" class="logo">
          </button>
      </div>

      <div class="logo-container">
          <button type="button" class="logo-button" onclick="checkSession_2()">
              <img src="./images/shopping_car.jpg" class="logo">
          </button>
      </div>
  </div>
      <script>
        function checkSession_1() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'profile.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
          function checkSession_2() {
            // 使用Ajax向服务器端发送请求检查session值
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.loggedIn) {
                        // 如果会话中的值为true，则跳转至profile.php
                        window.location.href = 'cart.php';
                    } else {
                        // 如果会话中的值为false，则发出警告并跳转至login.php
                        alert("請先登入帳號");
                        window.location.href = 'login.php';
                    }
                }
            };

            xhr.send();
          }
        </script>
  <div class="menu-buttons">
      <button type="button" class="menu-button" onclick="redirectToMenu('個人餐')">個人餐</button>
      <button type="button" class="menu-button" onclick="redirectToMenu('多人餐')">多人餐</button>
      <button type="button" class="menu-button" onclick="redirectToMenu('早餐')">早餐</button>
      <button type="button" class="menu-button" onclick="redirectToMenu('單點')">單點</button>
  </div>
  
  <div class="container">
    <div class="carousel-container">
      <div class="image-container">
        <img src="/images/KFC_menu1.jpg" alt="Image 1">
        <img src="/images/KFC_menu2.jpg" alt="Image 2">
        <img src="/images/KFC_menu3.jpg" alt="Image 3">
        <img src="/images/KFC_menu1.jpg" alt="Image 1">
      </div>
    </div>
  </div>
  <script>
    const container = document.querySelector('.image-container');
    let counter = 0;
    const intervalTime = 4000;
    let count_img = 0;
    function nextImage() {
      count_img = (counter++)%3;
      updateTransform();
    }

    function updateTransform() {
      const transformValue = -counter * 100 + '%';
      container.style.transition = 'transform 0.5s ease';

      container.style.transform = 'translateX(' + transformValue + ')';

      // Reset to the first image after reaching the duplicate
      if (counter === 3) {
        setTimeout(() => {
          container.style.transition = 'none';
          counter = 0;
          container.style.transform = 'translateX(0)';
        }, 500);
      }

      // Reset to the last image after reaching the duplicate in the opposite direction
      if (counter === -1) {
        setTimeout(() => {
          container.style.transition = 'none';
          counter = 2;
          container.style.transform = 'translateX(' + (-counter * 100) + '%)';
        }, 500);
      }
    }

    // Auto-run the carousel
    setInterval(nextImage, intervalTime);
  </script>

  <div class="card-container">
    <div class="content-buttons-container">
      <button onclick="showContent('content1', this)" class="content-button active-button"><h3>預定取餐</h3></button>
      <button onclick="showContent('content2', this)" class="content-button"><h3>專業外送</h3></button>
    </div>
  
    <div id="content1" class="content-box" style="display: block;">
      <h4>地點依縣市尋找:</h4>
      <select id="counties" name="counties" onchange="updateDistricts()">
          <option value="" disabled selected>請選擇</option>
          <option value="台北市">台北市</option>
          <option value="新北市">新北市</option>
          <option value="桃園市">桃園市</option>
          <!-- 其他縣市的選項 -->
      </select>
  
      <select id="districts" name="districts" onchange="updateDistricts()">
          <option value="" disabled selected>請選擇</option>
      </select>
      <div id="result-container"></div>
  
      <div id="datetime-container" style="margin-top: 10px;"></div>
  </div>
  
  <div id="content2" class="content-box">
    <input type="text" id="useraddress" name="useraddress" placeholder="請輸入包含縣市區的外送地址" onchange="showSelectedDate()">
    <div id="datetime-container-delivery"></div>
  </div>
  
  <div class="centered-button">
      <button onclick="orderFood()">前往訂餐</button>
  </div>
  
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      // Initially show content1 and set button color
      var initialButton = document.querySelector('.content-button.active-button');
      var initialContentId = initialButton.getAttribute('onclick').match(/'([^']+)'/)[1];
      showContent(initialContentId, initialButton);
    });
  
    function showContent(contentId, button) {
      // Hide all content boxes
      var allContents = document.querySelectorAll(".content-box");
      allContents.forEach(function(content) {
        content.style.display = "none";
      });
  
      // Deactivate all buttons
      var allButtons = document.querySelectorAll(".content-button");
      allButtons.forEach(function(btn) {
        btn.classList.remove("active-button");
      });
  
      // Show the selected content box
      var selectedContent = document.getElementById(contentId);
      selectedContent.style.display = "block";
  
      // Activate the current button
      button.classList.add("active-button");
    }
  </script>
  <!--choose the address-->
  <script>
    function updateDistricts() {
      var countiesSelect = document.getElementById("counties");
      var districtsSelect = document.getElementById("districts");
      var selectedDistrictDisplay = document.getElementById("selectedDistrictDisplay");
      var datetimeContainer = document.getElementById("datetime-container");
  
      var selectedCounty = countiesSelect.value;
      var selectedDistrict = districtsSelect.value;
  
      // 保存当前选定的區域
      var previousSelectedDistrict = selectedDistrict;
  
      // 清空區的選項
      districtsSelect.innerHTML = '<option value="" disabled selected>請選擇</option>';
  
      if (!selectedCounty) {
          // 如果未選擇縣市，隱藏日期輸入框和區域顯示
          if (datetimeContainer.firstChild) {
              datetimeContainer.removeChild(datetimeContainer.firstChild);
          }
          return;
      }
  
      if (selectedCounty === "台北市" || selectedCounty === "新北市" || selectedCounty === "桃園市") {
          var taipeiDistricts = ['大同區', '中山區', '中正區'];
          var newTaipeiDistricts = ['新莊區', '三重區', '板橋區'];
          var taoyuanDistricts = ['龜山區', '桃園區', '蘆竹區'];
  
          // 根據所選的縣市添加對應的區選項
          var districts;

          switch (selectedCounty) {
              case "台北市":
                  districts = taipeiDistricts;
                  break;
              case "新北市":
                  districts = newTaipeiDistricts;
                  break;
              // Add additional cases for other options if needed
              case "桃園市":
                  districts = taoyuanDistricts;
                  break;
              default:
                  districts = taipeiDistricts;
          }

          districts.forEach(function (district) {
              var option = document.createElement("option");
              option.value = district;
              option.text = district;
              districtsSelect.add(option);
          });

          if (selectedCounty && selectedDistrict) {
              var xhr = new XMLHttpRequest();
              xhr.open("POST", "restaurants.php", true);
              xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
              xhr.onreadystatechange = function () {
                  if (xhr.readyState == 4 && xhr.status == 200) {
                      // 将查询结果显示在屏幕上，您可以根据需要进行调整
                      var resultContainer = document.getElementById("result-container");
                      resultContainer.innerHTML = xhr.responseText;
                  }
              };

              // 发送POST请求
              var params = "selectedCounty=" + selectedCounty + "&selectedDistrict=" + selectedDistrict;
              xhr.send(params);
          }
  
          // 如果選擇了縣市和區，顯示日期輸入框和區域顯示
          if (previousSelectedDistrict) {
              // 如果之前有選擇區域，將它重新選擇
              districtsSelect.value = previousSelectedDistrict;
          }
  
          if (districtsSelect.value) {
              if (!datetimeContainer.firstChild) {
                  var datetimeInput = document.createElement("input");
                  datetimeInput.type = "datetime-local";
                  datetimeInput.id = "datetime";
                  datetimeInput.name = "datetime";
                  datetimeContainer.appendChild(datetimeInput);
              } 
          } else {
              // 如果未選擇區域，隱藏日期輸入框和區域顯示
              if (datetimeContainer.firstChild) {
                  datetimeContainer.removeChild(datetimeContainer.firstChild);
              } 
          }
        }
      }
  </script>
  
  <script>
    function orderFood() {
    var selectedCounty = document.getElementById("counties").value;
    var selectedDistrict = document.getElementById("districts").value;
    var datetimeInput = document.getElementById("datetime");
    var selectedDate = datetimeInput ? datetimeInput.value : null;

    // 傳送資訊至伺服器端
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "process_order.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // 這裡可以處理伺服器回傳的任何資訊
            console.log(xhr.responseText);
            alert('請開始點餐!');
            window.location.href = 'personal_meal.php';
        }
    };

    // 設定 POST 資料
    var params = "&selectedCounty=" + encodeURIComponent(selectedCounty) +
                 "&selectedDistrict=" + encodeURIComponent(selectedDistrict) +
                 "&selectedDate=" + encodeURIComponent(selectedDate);

    xhr.send(params);
}

</script>
<script>
  function showSelectedDate() {
    // 獲取地址輸入框的值
    var datetimeContainer = document.getElementById("datetime-container-delivery");
    
    if (!datetimeContainer.firstChild) {
        var datetimeInput = document.createElement("input");
        datetimeInput.type = "datetime-local";
        datetimeInput.id = "datetime";
        datetimeInput.name = "datetime";
        datetimeContainer.appendChild(datetimeInput);
    } 
  }
</script>
  <!--Package combination  choose-->
  <div class = "meals-title">個人餐</div>
  <div class="meals-container">
    <div class="meals">
      <a href="personal_meal.php#XL">
        <img src="./images/XL餐.jpg" alt="meals Image 1">
        <h2>XL 超豪!肯餐</h2>
      </a>
    </div>
    <div class="meals">
      <a href="personal_meal.php#L">
        <img src="./images/L餐.jpg" alt="meals Image 2">
        <h2>L 絕配餐</h2>
      </a>
    </div>
    <div class="meals">
      <a href="personal_meal.php#M">
        <img src="./images/M餐.jpg" alt="meals Image 3">
        <h2>M 經典餐</h2>
      </a>
    </div>
    <div class="meals">
      <a href="personal_meal.php#S">
        <img src="./images/S餐.jpg" alt="meals Image 4">
        <h2>S 雞勵餐</h2>
      </a>
    </div>
    <div class="meals">
      <a href="personal_meal.php#salad">
        <img src="./images/上校私廚沙拉.jpg" alt="meals Image 4">
        <h2>上校私廚沙拉</h2>
      </a>
    </div>
  </div>
  <div class = "meals-title">多人餐</div>
  <div class="meals-container">
    <div class="meals">
      <a href="family_meal.php#2to4">
        <img src="./images/2-4人.jpg" alt="meals Image 1">
        <h2>2-4人歡聚餐</h2>
      </a>
    </div>
    <div class="meals">
      <a href="family_meal.php#5to7">
        <img src="./images/5-7人.jpg" alt="meals Image 2">
        <h2>5-7人歡聚餐</h2>
      </a>
    </div>
  </div>
  <div class = "meals-title">早餐</div>
  <div class="meals-container">
    <div class="meals">
      <a href="breakfast.php#package">
        <img src="./images/早餐套餐.jpg" alt="meals Image 1">
        <h2>早餐套餐</h2>
      </a>
    </div>
    <div class="meals">
      <a href="breakfast.php#single">
        <img src="./images/早餐單點.jpg" alt="meals Image 2">
        <h2>早餐單點</h2>
      </a>
    </div>
  </div>
  <div class = "meals-title">單點</div>
  <div class="meals-container">
    <div class="meals">
      <a href="single_item.php#single_meal">
        <img src="./images/單點主餐.jpg" alt="meals Image 1">
        <h2>單點主餐</h2>
      </a>
    </div>
    <div class="meals">
      <a href="single_item.php#egg_tart">
        <img src="./images/蛋撻.jpg" alt="meals Image 2">
        <h2>蛋撻</h2>
      </a>
    </div>
    <div class="meals">
      <a href="single_item.php#dessert">
        <img src="./images/附餐點心.jpg" alt="meals Image 2">
        <h2>附餐/點心</h2>
      </a>
    </div>
    <div class="meals">
      <a href="single_item.php#drink">
        <img src="./images/飲料湯品.jpg" alt="meals Image 2">
        <h2>飲料/湯品</h2>
      </a>
    </div>
  </div>
  <footer>
    &copy; 2023 Software Term Project
  </footer>
</body>
</html>