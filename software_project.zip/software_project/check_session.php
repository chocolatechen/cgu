<?php
session_start();

$response = array('loggedIn' => false);

if (isset($_SESSION['member_id']) && $_SESSION['member_id'] == true) {
    $response['loggedIn'] = true;
}

header('Content-Type: application/json'); // 设置内容类型为 JSON
echo json_encode($response);
?>